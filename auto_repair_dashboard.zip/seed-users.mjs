import mysql from 'mysql2/promise';
import bcrypt from 'bcryptjs';

const connection = await mysql.createConnection(process.env.DATABASE_URL);

console.log('🌱 Starting user seed...');

// Hash passwords
const adminPassword = await bcrypt.hash('admin2543', 10);
const employeePassword = await bcrypt.hash('employee123', 10);

// เพิ่มข้อมูลผู้ใช้
try {
  await connection.execute(
    `INSERT INTO users (username, password, name, email, role, phone, position, salary) VALUES 
    ('admin', ?, 'ผู้ดูแลระบบ', 'admin@neofix.com', 'admin', '080-000-0000', 'ผู้จัดการ', 50000),
    ('somchai', ?, 'สมชาย ช่างดี', 'somchai@neofix.com', 'employee', '081-111-1111', 'ช่างซ่อมอาวุโส', 25000),
    ('wichai', ?, 'วิชัย ใจเย็น', 'wichai@neofix.com', 'employee', '082-222-2222', 'ช่างซ่อม', 20000)`,
    [adminPassword, employeePassword, employeePassword]
  );

  console.log('✅ Added 3 users (1 admin, 2 employees)');
  console.log('\n📋 Login Credentials:');
  console.log('Admin: username=admin, password=admin2543');
  console.log('Employee 1: username=somchai, password=employee123');
  console.log('Employee 2: username=wichai, password=employee123');
} catch (error) {
  if (error.code === 'ER_DUP_ENTRY') {
    console.log('⚠️  Users already exist, skipping...');
  } else {
    console.error('❌ Error creating users:', error);
  }
}

await connection.end();

console.log('🎉 User seed completed!');
