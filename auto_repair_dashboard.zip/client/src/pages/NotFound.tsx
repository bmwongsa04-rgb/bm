import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md glass border-destructive/50 shadow-[0_0_30px_var(--color-destructive)_inset]">
        <CardContent className="pt-6">
          <div className="flex mb-4 gap-2 items-center justify-center">
            <AlertCircle className="h-8 w-8 text-destructive animate-pulse" />
            <h1 className="text-2xl font-bold font-display text-destructive neon-text">404 SYSTEM ERROR</h1>
          </div>

          <div className="text-center space-y-4">
            <h2 className="text-4xl font-bold font-mono text-foreground">PAGE NOT FOUND</h2>
            <p className="text-sm text-muted-foreground">
              The requested module could not be located in the system memory.
              <br />
              Please return to the main control panel.
            </p>
          </div>
          
          <div className="mt-8 flex justify-center">
             <Link href="/">
              <Button variant="outline" className="border-primary/50 text-primary hover:bg-primary/10 hover:text-primary shadow-[0_0_10px_var(--color-primary)_inset]">
                Return to Dashboard
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
