import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Search, 
  Plus, 
  MoreHorizontal, 
  Calendar, 
  User, 
  Car, 
  Wrench,
  CheckCircle2,
  Clock,
  AlertTriangle,
  FileText,
  X
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function Repairs() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("ทั้งหมด");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  // Form state
  const [formData, setFormData] = useState({
    repairCode: "",
    vehicleId: "",
    customerId: "",
    assignedTo: "",
    description: "",
    estimatedCost: "",
    notes: "",
  });

  // Fetch repairs data
  const { data: repairs = [], isLoading, refetch } = trpc.repairs.getAll.useQuery();
  
  // Fetch customers and vehicles for dropdowns
  const { data: customers = [] } = trpc.customers.getAll.useQuery();
  const { data: users = [] } = trpc.auth.getAllUsers.useQuery();

  // Create repair mutation
  const createRepairMutation = trpc.repairs.create.useMutation({
    onSuccess: () => {
      toast.success("เปิดงานซ่อมสำเร็จ");
      refetch();
      setIsDialogOpen(false);
      resetForm();
    },
    onError: (error) => {
      toast.error(`เกิดข้อผิดพลาด: ${error.message}`);
    },
  });

  // Delete repair mutation
  const deleteRepairMutation = trpc.repairs.delete.useMutation({
    onSuccess: () => {
      toast.success("ลบงานซ่อมสำเร็จ");
      refetch();
    },
    onError: (error) => {
      toast.error(`เกิดข้อผิดพลาด: ${error.message}`);
    },
  });

  // Update repair status mutation
  const updateRepairMutation = trpc.repairs.update.useMutation({
    onSuccess: () => {
      toast.success("อัปเดตสถานะสำเร็จ");
      refetch();
    },
    onError: (error) => {
      toast.error(`เกิดข้อผิดพลาด: ${error.message}`);
    },
  });

  const resetForm = () => {
    setFormData({
      repairCode: "",
      vehicleId: "",
      customerId: "",
      assignedTo: "",
      description: "",
      estimatedCost: "",
      notes: "",
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.repairCode || !formData.vehicleId || !formData.customerId || !formData.description) {
      toast.error("กรุณากรอกข้อมูลที่จำเป็นให้ครบถ้วน");
      return;
    }

    createRepairMutation.mutate({
      repairCode: formData.repairCode,
      vehicleId: parseInt(formData.vehicleId),
      customerId: parseInt(formData.customerId),
      assignedTo: formData.assignedTo ? parseInt(formData.assignedTo) : undefined,
      description: formData.description,
      estimatedCost: formData.estimatedCost ? parseFloat(formData.estimatedCost) : undefined,
      notes: formData.notes || undefined,
      status: "pending",
    });
  };

  const handleDelete = (id: number) => {
    if (confirm("คุณแน่ใจหรือไม่ว่าต้องการลบงานซ่อมนี้?")) {
      deleteRepairMutation.mutate({ id });
    }
  };

  const handleStatusUpdate = (id: number, status: "pending" | "in_progress" | "completed" | "cancelled") => {
    updateRepairMutation.mutate({ id, status });
  };

  // Filter repairs
  const filteredRepairs = repairs.filter(repair => {
    const matchesSearch = 
      repair.repairCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      repair.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const statusMap: Record<string, string> = {
      "pending": "รอดำเนินการ",
      "in_progress": "กำลังดำเนินการ",
      "completed": "เสร็จสิ้น",
      "cancelled": "ยกเลิก"
    };
    
    const matchesStatus = statusFilter === "ทั้งหมด" || statusMap[repair.status] === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'completed': return 'border-emerald-500/50 text-emerald-400 bg-emerald-500/10';
      case 'in_progress': return 'border-blue-500/50 text-blue-400 bg-blue-500/10';
      case 'pending': return 'border-yellow-500/50 text-yellow-400 bg-yellow-500/10';
      case 'cancelled': return 'border-red-500/50 text-red-400 bg-red-500/10';
      default: return 'border-white/20 text-muted-foreground bg-white/5';
    }
  };

  const getStatusIcon = (status: string) => {
    switch(status) {
      case 'completed': return <CheckCircle2 className="w-3 h-3 mr-1" />;
      case 'in_progress': return <Wrench className="w-3 h-3 mr-1" />;
      case 'pending': return <Clock className="w-3 h-3 mr-1" />;
      case 'cancelled': return <AlertTriangle className="w-3 h-3 mr-1" />;
      default: return null;
    }
  };

  const getStatusText = (status: string) => {
    const statusMap: Record<string, string> = {
      "pending": "รอดำเนินการ",
      "in_progress": "กำลังดำเนินการ",
      "completed": "เสร็จสิ้น",
      "cancelled": "ยกเลิก"
    };
    return statusMap[status] || status;
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-96">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
            <p className="mt-4 text-muted-foreground">กำลังโหลดข้อมูล...</p>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h2 className="text-3xl font-bold tracking-tight font-display neon-text">จัดการงานซ่อม</h2>
            <p className="text-muted-foreground mt-1">
              ติดตามและจัดการงานซ่อมรถยนต์ทั้งหมดในอู่
            </p>
          </div>
          
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_15px_var(--color-primary)] border-none">
                <Plus className="mr-2 h-4 w-4" /> เปิดงานซ่อมใหม่
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto glass border-primary/20">
              <DialogHeader>
                <DialogTitle className="text-2xl font-display neon-text">เปิดงานซ่อมใหม่</DialogTitle>
                <DialogDescription>
                  กรอกข้อมูลการซ่อมเพื่อเปิดงานใหม่ในระบบ
                </DialogDescription>
              </DialogHeader>
              
              <form onSubmit={handleSubmit} className="space-y-4 mt-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="repairCode">รหัสงานซ่อม *</Label>
                    <Input
                      id="repairCode"
                      placeholder="เช่น R-1025"
                      value={formData.repairCode}
                      onChange={(e) => setFormData({...formData, repairCode: e.target.value})}
                      className="bg-background/50 border-white/10"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="customerId">ลูกค้า *</Label>
                    <Select
                      value={formData.customerId}
                      onValueChange={(value) => setFormData({...formData, customerId: value})}
                      required
                    >
                      <SelectTrigger className="bg-background/50 border-white/10">
                        <SelectValue placeholder="เลือกลูกค้า" />
                      </SelectTrigger>
                      <SelectContent className="bg-card border-white/10">
                        {customers.map((customer) => (
                          <SelectItem key={customer.id} value={customer.id.toString()}>
                            {customer.firstName} {customer.lastName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="vehicleId">รหัสยานพาหนะ *</Label>
                    <Input
                      id="vehicleId"
                      type="number"
                      placeholder="เช่น 1"
                      value={formData.vehicleId}
                      onChange={(e) => setFormData({...formData, vehicleId: e.target.value})}
                      className="bg-background/50 border-white/10"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="assignedTo">มอบหมายให้ช่าง</Label>
                    <Select
                      value={formData.assignedTo}
                      onValueChange={(value) => setFormData({...formData, assignedTo: value})}
                    >
                      <SelectTrigger className="bg-background/50 border-white/10">
                        <SelectValue placeholder="เลือกช่าง" />
                      </SelectTrigger>
                      <SelectContent className="bg-card border-white/10">
                        {users.filter(u => u.role === 'employee').map((user) => (
                          <SelectItem key={user.id} value={user.id.toString()}>
                            {user.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">รายละเอียดการซ่อม *</Label>
                  <Textarea
                    id="description"
                    placeholder="อธิบายอาการหรือรายการซ่อม..."
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                    className="bg-background/50 border-white/10 min-h-[100px]"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="estimatedCost">ค่าใช้จ่ายโดยประมาณ (฿)</Label>
                    <Input
                      id="estimatedCost"
                      type="number"
                      step="0.01"
                      placeholder="0.00"
                      value={formData.estimatedCost}
                      onChange={(e) => setFormData({...formData, estimatedCost: e.target.value})}
                      className="bg-background/50 border-white/10"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">หมายเหตุ</Label>
                  <Textarea
                    id="notes"
                    placeholder="หมายเหตุเพิ่มเติม..."
                    value={formData.notes}
                    onChange={(e) => setFormData({...formData, notes: e.target.value})}
                    className="bg-background/50 border-white/10"
                  />
                </div>

                <div className="flex gap-3 justify-end pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsDialogOpen(false)}
                    className="border-white/10"
                  >
                    ยกเลิก
                  </Button>
                  <Button
                    type="submit"
                    disabled={createRepairMutation.isPending}
                    className="bg-primary text-primary-foreground"
                  >
                    {createRepairMutation.isPending ? "กำลังบันทึก..." : "เปิดงานซ่อม"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Filters and Search */}
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between bg-card/30 p-4 rounded-xl border border-white/5 backdrop-blur-sm">
          <div className="relative w-full md:w-96">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="ค้นหาด้วยรหัสงาน หรือรายละเอียด..." 
              className="pl-9 bg-background/50 border-white/10 focus:border-primary/50 focus:ring-primary/20"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex gap-2 w-full md:w-auto overflow-x-auto pb-2 md:pb-0">
            {['ทั้งหมด', 'กำลังดำเนินการ', 'เสร็จสิ้น', 'รอดำเนินการ', 'ยกเลิก'].map((status) => (
              <Button
                key={status}
                variant={statusFilter === status ? "default" : "outline"}
                size="sm"
                onClick={() => setStatusFilter(status)}
                className={statusFilter === status 
                  ? "bg-primary text-primary-foreground border-primary" 
                  : "bg-transparent border-white/10 text-muted-foreground hover:text-foreground hover:bg-white/5"
                }
              >
                {status}
              </Button>
            ))}
          </div>
        </div>

        {/* Repairs List */}
        <div className="grid gap-4">
          {filteredRepairs.length > 0 ? (
            filteredRepairs.map((repair) => (
              <Card key={repair.id} className="glass border-primary/20 hover:border-primary/50 transition-all duration-300 group">
                <CardContent className="p-6">
                  <div className="flex flex-col lg:flex-row gap-6 items-start lg:items-center justify-between">
                    
                    {/* Job Info */}
                    <div className="flex items-start gap-4 min-w-[200px]">
                      <div className="p-3 rounded-xl bg-primary/10 border border-primary/20 group-hover:bg-primary/20 transition-colors">
                        <Car className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-bold font-display text-lg">{repair.repairCode}</h3>
                          <Badge variant="outline" className={getStatusColor(repair.status)}>
                            {getStatusIcon(repair.status)}
                            {getStatusText(repair.status)}
                          </Badge>
                        </div>
                        <p className="text-muted-foreground text-sm mt-1 flex items-center gap-1">
                          <Calendar className="w-3 h-3" /> {new Date(repair.createdAt).toLocaleDateString('th-TH')}
                        </p>
                      </div>
                    </div>

                    {/* Description */}
                    <div className="flex-1 w-full lg:w-auto">
                      <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">รายละเอียดบริการ</p>
                      <p className="text-sm line-clamp-2">{repair.description}</p>
                      {repair.notes && (
                        <p className="text-xs text-muted-foreground mt-1">หมายเหตุ: {repair.notes}</p>
                      )}
                    </div>

                    {/* Amount & Actions */}
                    <div className="flex items-center justify-between w-full lg:w-auto gap-6 mt-4 lg:mt-0 pt-4 lg:pt-0 border-t lg:border-t-0 border-white/10">
                      <div className="text-right">
                        <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">ยอดประมาณ</p>
                        <p className="font-bold font-mono text-xl text-primary">
                          ฿{(repair.estimatedCost || 0).toLocaleString()}
                        </p>
                      </div>
                      
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-48 bg-card border-white/10 backdrop-blur-xl">
                          <DropdownMenuLabel>การจัดการ</DropdownMenuLabel>
                          <DropdownMenuItem onClick={() => handleStatusUpdate(repair.id, "in_progress")}>
                            <Wrench className="mr-2 h-4 w-4" /> เริ่มดำเนินการ
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleStatusUpdate(repair.id, "completed")}>
                            <CheckCircle2 className="mr-2 h-4 w-4" /> ทำเสร็จแล้ว
                          </DropdownMenuItem>
                          <DropdownMenuSeparator className="bg-white/10" />
                          <DropdownMenuItem 
                            className="text-destructive focus:text-destructive"
                            onClick={() => handleDelete(repair.id)}
                          >
                            <X className="mr-2 h-4 w-4" /> ลบงาน
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>

                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="text-center py-12 bg-card/30 rounded-xl border border-white/5 border-dashed">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-white/5 mb-4">
                <Search className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-medium">ไม่พบข้อมูลงานซ่อม</h3>
              <p className="text-muted-foreground mt-1">ลองปรับเปลี่ยนคำค้นหาหรือตัวกรองของคุณ</p>
              <Button 
                variant="link" 
                onClick={() => {setSearchTerm(""); setStatusFilter("ทั้งหมด");}}
                className="mt-2 text-primary"
              >
                ล้างตัวกรองทั้งหมด
              </Button>
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
