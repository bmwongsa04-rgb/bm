import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/contexts/AuthContext";
import { Wrench } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

export default function Login() {
  const [, setLocation] = useLocation();
  const { login } = useAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      await login(username, password);
      toast.success("เข้าสู่ระบบสำเร็จ");
      setLocation("/dashboard");
    } catch (error) {
      toast.error("ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[url('/images/hero-bg.png')] bg-cover bg-center relative">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
      
      <Card className="w-full max-w-md z-10 glass border-primary/30 shadow-[0_0_50px_rgba(0,255,255,0.1)]">
        <CardHeader className="text-center">
          <div className="mx-auto w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center border-2 border-primary mb-4 shadow-[0_0_20px_var(--color-primary)]">
            <Wrench className="w-8 h-8 text-primary" />
          </div>
          <CardTitle className="text-3xl font-display font-bold neon-text">NEO-FIX</CardTitle>
          <CardDescription className="text-base">ระบบจัดการอู่ซ่อมรถและร้านค้า</CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-foreground">ชื่อผู้ใช้</Label>
              <Input
                id="username"
                type="text"
                placeholder="กรอกชื่อผู้ใช้"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                disabled={loading}
                className="bg-background/50 border-white/20"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-foreground">รหัสผ่าน</Label>
              <Input
                id="password"
                type="password"
                placeholder="กรอกรหัสผ่าน"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                disabled={loading}
                className="bg-background/50 border-white/20"
              />
            </div>
            <Button 
              type="submit" 
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_15px_var(--color-primary)] hover:shadow-[0_0_25px_var(--color-primary)] transition-all"
              size="lg"
              disabled={loading}
            >
              {loading ? "กำลังเข้าสู่ระบบ..." : "เข้าสู่ระบบ"}
            </Button>
          </form>

          <div className="pt-6 border-t border-white/10 text-center">
            <p className="text-sm text-muted-foreground mb-3">
              ลูกค้าทั่วไปสามารถเข้าชมร้านค้าได้โดยไม่ต้องเข้าสู่ระบบ
            </p>
            <Button 
              variant="outline"
              onClick={() => setLocation("/shop")}
              className="w-full border-white/20 hover:bg-white/5"
            >
              <Wrench className="mr-2 h-4 w-4" />
              เข้าชมร้านค้า (ไม่ต้องล็อกอิน)
            </Button>
          </div>
        </CardContent>

        <div className="text-center pb-6 text-xs text-muted-foreground">
          © 2025 Neo-Fix Auto Service System
        </div>
      </Card>
    </div>
  );
}
