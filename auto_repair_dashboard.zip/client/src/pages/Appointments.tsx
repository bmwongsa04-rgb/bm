import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Plus, 
  Clock,
  User,
  Car,
  Phone,
  Calendar as CalendarIcon,
  Pencil,
  Trash2,
  CheckCircle2,
  XCircle
} from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

interface AppointmentFormData {
  id?: number;
  customerId: number;
  vehicleId: number;
  appointmentDate: string;
  appointmentTime: string;
  serviceType: string;
  notes: string;
  status: string;
}

export default function Appointments() {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState<any>(null);
  const [formData, setFormData] = useState<AppointmentFormData>({
    customerId: 0,
    vehicleId: 0,
    appointmentDate: new Date().toISOString().split('T')[0],
    appointmentTime: "09:00",
    serviceType: "",
    notes: "",
    status: "pending",
  });

  const { data: appointments, refetch: refetchAppointments } = trpc.appointments.getAll.useQuery();
  const { data: customers } = trpc.customers.getAll.useQuery();
  const createAppointmentMutation = trpc.appointments.create.useMutation();
  const updateAppointmentMutation = trpc.appointments.update.useMutation();
  const deleteAppointmentMutation = trpc.appointments.delete.useMutation();

  // Filter appointments by selected date
  const filteredAppointments = appointments?.filter(app => {
    if (!selectedDate) return true;
    const appDate = new Date(app.appointmentDate);
    return appDate.toDateString() === selectedDate.toDateString();
  }) || [];

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'confirmed': return 'border-emerald-500/50 text-emerald-400 bg-emerald-500/10';
      case 'pending': return 'border-yellow-500/50 text-yellow-400 bg-yellow-500/10';
      case 'cancelled': return 'border-destructive/50 text-destructive bg-destructive/10';
      case 'completed': return 'border-blue-500/50 text-blue-400 bg-blue-500/10';
      default: return 'border-white/20 text-muted-foreground bg-white/5';
    }
  };

  const getStatusText = (status: string) => {
    switch(status) {
      case 'confirmed': return 'ยืนยันแล้ว';
      case 'pending': return 'รอยืนยัน';
      case 'cancelled': return 'ยกเลิก';
      case 'completed': return 'เสร็จสิ้น';
      default: return status;
    }
  };

  const handleAddAppointment = async () => {
    if (formData.customerId === 0) {
      toast.error("กรุณาเลือกลูกค้า");
      return;
    }
    try {
      await createAppointmentMutation.mutateAsync(formData);
      toast.success("เพิ่มนัดหมายสำเร็จ");
      setIsAddDialogOpen(false);
      refetchAppointments();
      resetForm();
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาดในการเพิ่มนัดหมาย");
    }
  };

  const handleEditAppointment = async () => {
    if (!selectedAppointment) return;
    try {
      await updateAppointmentMutation.mutateAsync({
        id: selectedAppointment.id,
        ...formData,
      });
      toast.success("แก้ไขนัดหมายสำเร็จ");
      setIsEditDialogOpen(false);
      refetchAppointments();
      resetForm();
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาดในการแก้ไขนัดหมาย");
    }
  };

  const handleDeleteAppointment = async (id: number) => {
    if (!confirm("คุณแน่ใจหรือไม่ที่จะลบนัดหมายนี้?")) return;
    try {
      await deleteAppointmentMutation.mutateAsync({ id });
      toast.success("ลบนัดหมายสำเร็จ");
      refetchAppointments();
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาดในการลบนัดหมาย");
    }
  };

  const handleConfirmAppointment = async (id: number) => {
    try {
      await updateAppointmentMutation.mutateAsync({
        id,
        status: "confirmed",
      });
      toast.success("ยืนยันนัดหมายสำเร็จ");
      refetchAppointments();
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาด");
    }
  };

  const handleCancelAppointment = async (id: number) => {
    if (!confirm("คุณแน่ใจหรือไม่ที่จะยกเลิกนัดหมายนี้?")) return;
    try {
      await updateAppointmentMutation.mutateAsync({
        id,
        status: "cancelled",
      });
      toast.success("ยกเลิกนัดหมายสำเร็จ");
      refetchAppointments();
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาด");
    }
  };

  const resetForm = () => {
    setFormData({
      customerId: 0,
      vehicleId: 0,
      appointmentDate: new Date().toISOString().split('T')[0],
      appointmentTime: "09:00",
      serviceType: "",
      notes: "",
      status: "pending",
    });
    setSelectedAppointment(null);
  };

  const openEditDialog = (appointment: any) => {
    setSelectedAppointment(appointment);
    setFormData({
      customerId: appointment.customerId,
      vehicleId: appointment.vehicleId || 0,
      appointmentDate: new Date(appointment.appointmentDate).toISOString().split('T')[0],
      appointmentTime: appointment.appointmentTime,
      serviceType: appointment.serviceType,
      notes: appointment.notes || "",
      status: appointment.status,
    });
    setIsEditDialogOpen(true);
  };

  const getCustomerName = (customerId: number) => {
    const customer = customers?.find(c => c.id === customerId);
    return customer?.name || "ไม่ระบุ";
  };

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-display font-bold tracking-wider text-foreground">
              ตารางนัดหมาย
            </h1>
            <p className="text-muted-foreground mt-1">
              จัดการการจองคิวและตารางงานของช่าง
            </p>
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-primary/90">
                <Plus className="w-4 h-4 mr-2" />
                เพิ่มนัดหมายใหม่
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl glass border-primary/20">
              <DialogHeader>
                <DialogTitle>เพิ่มนัดหมายใหม่</DialogTitle>
                <DialogDescription>กรอกข้อมูลการนัดหมายที่ต้องการเพิ่มเข้าระบบ</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="add-customer">ลูกค้า *</Label>
                  <Select
                    value={formData.customerId.toString()}
                    onValueChange={(value) => setFormData({ ...formData, customerId: parseInt(value) })}
                  >
                    <SelectTrigger className="bg-background/50">
                      <SelectValue placeholder="เลือกลูกค้า" />
                    </SelectTrigger>
                    <SelectContent>
                      {!customers || customers.length === 0 ? (
                        <SelectItem value="0" disabled>ไม่มีข้อมูลลูกค้า - กรุณาเพิ่มลูกค้าก่อน</SelectItem>
                      ) : (
                        customers.map((customer) => (
                          <SelectItem key={customer.id} value={customer.id.toString()}>
                            {customer.name} ({customer.phone})
                          </SelectItem>
                        ))
                      )}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="add-date">วันที่นัดหมาย *</Label>
                    <Input
                      id="add-date"
                      type="date"
                      value={formData.appointmentDate}
                      onChange={(e) => setFormData({ ...formData, appointmentDate: e.target.value })}
                      className="bg-background/50"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="add-time">เวลา *</Label>
                    <Input
                      id="add-time"
                      type="time"
                      value={formData.appointmentTime}
                      onChange={(e) => setFormData({ ...formData, appointmentTime: e.target.value })}
                      className="bg-background/50"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="add-service">ประเภทบริการ *</Label>
                  <Select
                    value={formData.serviceType}
                    onValueChange={(value) => setFormData({ ...formData, serviceType: value })}
                  >
                    <SelectTrigger className="bg-background/50">
                      <SelectValue placeholder="เลือกประเภทบริการ" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="เปลี่ยนน้ำมันเครื่อง">เปลี่ยนน้ำมันเครื่อง</SelectItem>
                      <SelectItem value="ตรวจเช็คระยะ">ตรวจเช็คระยะ</SelectItem>
                      <SelectItem value="เปลี่ยนยาง">เปลี่ยนยาง</SelectItem>
                      <SelectItem value="ซ่อมเครื่องยนต์">ซ่อมเครื่องยนต์</SelectItem>
                      <SelectItem value="ซ่อมแอร์">ซ่อมแอร์</SelectItem>
                      <SelectItem value="ซ่อมระบบเบรก">ซ่อมระบบเบรก</SelectItem>
                      <SelectItem value="อื่นๆ">อื่นๆ</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="add-notes">หมายเหตุ</Label>
                  <Input
                    id="add-notes"
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    placeholder="รายละเอียดเพิ่มเติม..."
                    className="bg-background/50"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  ยกเลิก
                </Button>
                <Button onClick={handleAddAppointment} className="bg-primary hover:bg-primary/90">
                  เพิ่มนัดหมาย
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Calendar */}
          <Card className="glass border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CalendarIcon className="w-5 h-5" />
                ปฏิทิน
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                className="rounded-md border border-white/10"
              />
            </CardContent>
          </Card>

          {/* Appointments List */}
          <Card className="glass border-primary/20 lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                นัดหมายวันที่ {selectedDate?.toLocaleDateString('th-TH')}
              </CardTitle>
              <CardDescription>
                จำนวนนัดหมาย: {filteredAppointments.length} รายการ
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="border-white/10 hover:bg-white/5">
                    <TableHead>เวลา</TableHead>
                    <TableHead>ลูกค้า</TableHead>
                    <TableHead>บริการ</TableHead>
                    <TableHead>สถานะ</TableHead>
                    <TableHead className="text-right">จัดการ</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAppointments.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                        <CalendarIcon className="w-12 h-12 mx-auto mb-2 opacity-50" />
                        ไม่มีนัดหมายในวันนี้
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredAppointments.map((appointment) => (
                      <TableRow key={appointment.id} className="border-white/10 hover:bg-white/5">
                        <TableCell className="font-mono">{appointment.appointmentTime}</TableCell>
                        <TableCell>
                          <div>
                            <p className="font-medium">{getCustomerName(appointment.customerId)}</p>
                            <p className="text-xs text-muted-foreground">{appointment.notes}</p>
                          </div>
                        </TableCell>
                        <TableCell className="text-muted-foreground">{appointment.serviceType}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className={getStatusColor(appointment.status)}>
                            {getStatusText(appointment.status)}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            {appointment.status === 'pending' && (
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleConfirmAppointment(appointment.id)}
                                className="hover:bg-emerald-500/20 hover:text-emerald-400"
                                title="ยืนยัน"
                              >
                                <CheckCircle2 className="w-4 h-4" />
                              </Button>
                            )}
                            {appointment.status !== 'cancelled' && (
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleCancelAppointment(appointment.id)}
                                className="hover:bg-destructive/20 hover:text-destructive"
                                title="ยกเลิก"
                              >
                                <XCircle className="w-4 h-4" />
                              </Button>
                            )}
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => openEditDialog(appointment)}
                              className="hover:bg-primary/20 hover:text-primary"
                              title="แก้ไข"
                            >
                              <Pencil className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDeleteAppointment(appointment.id)}
                              className="hover:bg-destructive/20 hover:text-destructive"
                              title="ลบ"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>

        {/* Edit Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="max-w-2xl glass border-primary/20">
            <DialogHeader>
              <DialogTitle>แก้ไขนัดหมาย</DialogTitle>
              <DialogDescription>แก้ไขข้อมูลการนัดหมายในระบบ</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="edit-customer">ลูกค้า *</Label>
                <Select
                  value={formData.customerId.toString()}
                  onValueChange={(value) => setFormData({ ...formData, customerId: parseInt(value) })}
                >
                  <SelectTrigger className="bg-background/50">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {customers?.map((customer) => (
                      <SelectItem key={customer.id} value={customer.id.toString()}>
                        {customer.name} ({customer.phone})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-date">วันที่นัดหมาย *</Label>
                  <Input
                    id="edit-date"
                    type="date"
                    value={formData.appointmentDate}
                    onChange={(e) => setFormData({ ...formData, appointmentDate: e.target.value })}
                    className="bg-background/50"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-time">เวลา *</Label>
                  <Input
                    id="edit-time"
                    type="time"
                    value={formData.appointmentTime}
                    onChange={(e) => setFormData({ ...formData, appointmentTime: e.target.value })}
                    className="bg-background/50"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-service">ประเภทบริการ *</Label>
                <Select
                  value={formData.serviceType}
                  onValueChange={(value) => setFormData({ ...formData, serviceType: value })}
                >
                  <SelectTrigger className="bg-background/50">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="เปลี่ยนน้ำมันเครื่อง">เปลี่ยนน้ำมันเครื่อง</SelectItem>
                    <SelectItem value="ตรวจเช็คระยะ">ตรวจเช็คระยะ</SelectItem>
                    <SelectItem value="เปลี่ยนยาง">เปลี่ยนยาง</SelectItem>
                    <SelectItem value="ซ่อมเครื่องยนต์">ซ่อมเครื่องยนต์</SelectItem>
                    <SelectItem value="ซ่อมแอร์">ซ่อมแอร์</SelectItem>
                    <SelectItem value="ซ่อมระบบเบรก">ซ่อมระบบเบรก</SelectItem>
                    <SelectItem value="อื่นๆ">อื่นๆ</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-notes">หมายเหตุ</Label>
                <Input
                  id="edit-notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="bg-background/50"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-status">สถานะ</Label>
                <Select
                  value={formData.status}
                  onValueChange={(value) => setFormData({ ...formData, status: value })}
                >
                  <SelectTrigger className="bg-background/50">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">รอยืนยัน</SelectItem>
                    <SelectItem value="confirmed">ยืนยันแล้ว</SelectItem>
                    <SelectItem value="completed">เสร็จสิ้น</SelectItem>
                    <SelectItem value="cancelled">ยกเลิก</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                ยกเลิก
              </Button>
              <Button onClick={handleEditAppointment} className="bg-primary hover:bg-primary/90">
                บันทึกการแก้ไข
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
