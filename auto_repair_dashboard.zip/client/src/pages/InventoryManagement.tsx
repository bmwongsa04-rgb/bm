import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Search, 
  Plus, 
  Pencil,
  Trash2,
  Package,
  AlertTriangle,
  Upload,
  Image as ImageIcon
} from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

interface ProductFormData {
  id?: number;
  name: string;
  category: string;
  stock: number;
  price: number;
  minStock: number;
  description: string;
  imageUrl: string;
}

export default function InventoryManagement() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<any>(null);
  const [formData, setFormData] = useState<ProductFormData>({
    name: "",
    category: "",
    stock: 0,
    price: 0,
    minStock: 5,
    description: "",
    imageUrl: "",
  });

  const { data: products, refetch: refetchProducts } = trpc.inventory.getAll.useQuery();
  const createProductMutation = trpc.inventory.create.useMutation();
  const updateProductMutation = trpc.inventory.update.useMutation();
  const deleteProductMutation = trpc.inventory.delete.useMutation();

  const filteredProducts = products?.filter(item => 
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.category.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  const getStockStatus = (stock: number, minStock: number) => {
    if (stock === 0) return { label: "สินค้าหมด", color: "border-destructive/50 text-destructive bg-destructive/10" };
    if (stock <= minStock) return { label: "สินค้าใกล้หมด", color: "border-yellow-500/50 text-yellow-400 bg-yellow-500/10" };
    return { label: "มีสินค้า", color: "border-emerald-500/50 text-emerald-400 bg-emerald-500/10" };
  };

  const handleAddProduct = async () => {
    try {
      await createProductMutation.mutateAsync(formData);
      toast.success("เพิ่มสินค้าสำเร็จ");
      setIsAddDialogOpen(false);
      refetchProducts();
      resetForm();
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาดในการเพิ่มสินค้า");
    }
  };

  const handleEditProduct = async () => {
    if (!selectedProduct) return;
    try {
      await updateProductMutation.mutateAsync({
        id: selectedProduct.id,
        ...formData,
      });
      toast.success("แก้ไขสินค้าสำเร็จ");
      setIsEditDialogOpen(false);
      refetchProducts();
      resetForm();
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาดในการแก้ไขสินค้า");
    }
  };

  const handleDeleteProduct = async (id: number) => {
    if (!confirm("คุณแน่ใจหรือไม่ที่จะลบสินค้านี้?")) return;
    try {
      await deleteProductMutation.mutateAsync({ id });
      toast.success("ลบสินค้าสำเร็จ");
      refetchProducts();
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาดในการลบสินค้า");
    }
  };

  const resetForm = () => {
    setFormData({
      name: "",
      category: "",
      stock: 0,
      price: 0,
      minStock: 5,
      description: "",
      imageUrl: "",
    });
    setSelectedProduct(null);
  };

  const openEditDialog = (product: any) => {
    setSelectedProduct(product);
    setFormData({
      name: product.name,
      category: product.category,
      stock: product.stock,
      price: product.price,
      minStock: product.minStock || 5,
      description: product.description || "",
      imageUrl: product.imageUrl || "",
    });
    setIsEditDialogOpen(true);
  };

  const lowStockProducts = products?.filter(p => p.stock <= (p.minStock || 5) && p.stock > 0) || [];

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-display font-bold tracking-wider text-foreground">
              จัดการคลังสินค้า
            </h1>
            <p className="text-muted-foreground mt-1">
              เพิ่ม แก้ไข และจัดการสินค้าในระบบ
            </p>
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-primary/90">
                <Plus className="w-4 h-4 mr-2" />
                เพิ่มสินค้าใหม่
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl glass border-primary/20">
              <DialogHeader>
                <DialogTitle>เพิ่มสินค้าใหม่</DialogTitle>
                <DialogDescription>กรอกข้อมูลสินค้าที่ต้องการเพิ่มเข้าระบบ</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="add-name">ชื่อสินค้า *</Label>
                    <Input
                      id="add-name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="เช่น น้ำมันเครื่อง 5W-30"
                      className="bg-background/50"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="add-category">หมวดหมู่ *</Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) => setFormData({ ...formData, category: value })}
                    >
                      <SelectTrigger className="bg-background/50">
                        <SelectValue placeholder="เลือกหมวดหมู่" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ของเหลว">ของเหลว</SelectItem>
                        <SelectItem value="ไส้กรอง">ไส้กรอง</SelectItem>
                        <SelectItem value="เบรก">เบรก</SelectItem>
                        <SelectItem value="ระบบจุดระเบิด">ระบบจุดระเบิด</SelectItem>
                        <SelectItem value="ระบบไฟฟ้า">ระบบไฟฟ้า</SelectItem>
                        <SelectItem value="ภายนอก">ภายนอก</SelectItem>
                        <SelectItem value="อื่นๆ">อื่นๆ</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="add-stock">จำนวนสต็อก *</Label>
                    <Input
                      id="add-stock"
                      type="number"
                      value={formData.stock}
                      onChange={(e) => setFormData({ ...formData, stock: parseInt(e.target.value) || 0 })}
                      placeholder="0"
                      className="bg-background/50"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="add-price">ราคา (฿) *</Label>
                    <Input
                      id="add-price"
                      type="number"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) || 0 })}
                      placeholder="0.00"
                      className="bg-background/50"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="add-minStock">สต็อกขั้นต่ำ *</Label>
                    <Input
                      id="add-minStock"
                      type="number"
                      value={formData.minStock}
                      onChange={(e) => setFormData({ ...formData, minStock: parseInt(e.target.value) || 5 })}
                      placeholder="5"
                      className="bg-background/50"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="add-description">รายละเอียดสินค้า</Label>
                  <Input
                    id="add-description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="รายละเอียดเพิ่มเติม..."
                    className="bg-background/50"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="add-imageUrl">URL รูปภาพ</Label>
                  <div className="flex gap-2">
                    <Input
                      id="add-imageUrl"
                      value={formData.imageUrl}
                      onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                      placeholder="https://example.com/image.jpg"
                      className="bg-background/50"
                    />
                    <Button variant="outline" size="icon" title="อัปโหลดรูปภาพ">
                      <Upload className="w-4 h-4" />
                    </Button>
                  </div>
                  {formData.imageUrl && (
                    <div className="mt-2 p-2 border border-white/10 rounded-lg bg-background/30">
                      <img 
                        src={formData.imageUrl} 
                        alt="Preview" 
                        className="w-full h-32 object-cover rounded"
                        onError={(e) => {
                          e.currentTarget.src = "/placeholder-product.png";
                        }}
                      />
                    </div>
                  )}
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  ยกเลิก
                </Button>
                <Button onClick={handleAddProduct} className="bg-primary hover:bg-primary/90">
                  เพิ่มสินค้า
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Alert for Low Stock */}
        {lowStockProducts.length > 0 && (
          <Card className="glass border-yellow-500/30 bg-yellow-500/5">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-yellow-400 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-yellow-400">แจ้งเตือนสินค้าใกล้หมด</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    มีสินค้า {lowStockProducts.length} รายการที่ใกล้หมด: {lowStockProducts.map(p => p.name).join(", ")}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="ค้นหาสินค้าด้วยชื่อหรือหมวดหมู่..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-background/50 border-white/10"
          />
        </div>

        {/* Products Table */}
        <Card className="glass border-primary/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="w-5 h-5" />
              รายการสินค้าทั้งหมด
            </CardTitle>
            <CardDescription>
              จำนวนสินค้าทั้งหมด: {products?.length || 0} รายการ
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow className="border-white/10 hover:bg-white/5">
                  <TableHead>รูปภาพ</TableHead>
                  <TableHead>ชื่อสินค้า</TableHead>
                  <TableHead>หมวดหมู่</TableHead>
                  <TableHead className="text-right">สต็อก</TableHead>
                  <TableHead className="text-right">ราคา</TableHead>
                  <TableHead>สถานะ</TableHead>
                  <TableHead className="text-right">จัดการ</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredProducts.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                      <Package className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      ไม่พบข้อมูลสินค้า
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredProducts.map((product) => {
                    const status = getStockStatus(product.stock, product.minStock || 5);
                    return (
                      <TableRow key={product.id} className="border-white/10 hover:bg-white/5">
                        <TableCell>
                          <div className="w-12 h-12 rounded-lg overflow-hidden bg-background/30 border border-white/10 flex items-center justify-center">
                            {product.imageUrl ? (
                              <img 
                                src={product.imageUrl} 
                                alt={product.name}
                                className="w-full h-full object-cover"
                                onError={(e) => {
                                  e.currentTarget.style.display = 'none';
                                  e.currentTarget.parentElement!.innerHTML = '<div class="text-muted-foreground"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg></div>';
                                }}
                              />
                            ) : (
                              <ImageIcon className="w-6 h-6 text-muted-foreground" />
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="font-medium">{product.name}</TableCell>
                        <TableCell className="text-muted-foreground">{product.category}</TableCell>
                        <TableCell className="text-right font-mono">{product.stock}</TableCell>
                        <TableCell className="text-right font-mono">฿{product.price.toLocaleString()}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className={status.color}>
                            {status.label}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => openEditDialog(product)}
                              className="hover:bg-primary/20 hover:text-primary"
                            >
                              <Pencil className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDeleteProduct(product.id)}
                              className="hover:bg-destructive/20 hover:text-destructive"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Edit Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="max-w-2xl glass border-primary/20">
            <DialogHeader>
              <DialogTitle>แก้ไขสินค้า</DialogTitle>
              <DialogDescription>แก้ไขข้อมูลสินค้าในระบบ</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-name">ชื่อสินค้า *</Label>
                  <Input
                    id="edit-name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="bg-background/50"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-category">หมวดหมู่ *</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData({ ...formData, category: value })}
                  >
                    <SelectTrigger className="bg-background/50">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ของเหลว">ของเหลว</SelectItem>
                      <SelectItem value="ไส้กรอง">ไส้กรอง</SelectItem>
                      <SelectItem value="เบรก">เบรก</SelectItem>
                      <SelectItem value="ระบบจุดระเบิด">ระบบจุดระเบิด</SelectItem>
                      <SelectItem value="ระบบไฟฟ้า">ระบบไฟฟ้า</SelectItem>
                      <SelectItem value="ภายนอก">ภายนอก</SelectItem>
                      <SelectItem value="อื่นๆ">อื่นๆ</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-stock">จำนวนสต็อก *</Label>
                  <Input
                    id="edit-stock"
                    type="number"
                    value={formData.stock}
                    onChange={(e) => setFormData({ ...formData, stock: parseInt(e.target.value) || 0 })}
                    className="bg-background/50"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-price">ราคา (฿) *</Label>
                  <Input
                    id="edit-price"
                    type="number"
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) || 0 })}
                    className="bg-background/50"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-minStock">สต็อกขั้นต่ำ *</Label>
                  <Input
                    id="edit-minStock"
                    type="number"
                    value={formData.minStock}
                    onChange={(e) => setFormData({ ...formData, minStock: parseInt(e.target.value) || 5 })}
                    className="bg-background/50"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-description">รายละเอียดสินค้า</Label>
                <Input
                  id="edit-description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="bg-background/50"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-imageUrl">URL รูปภาพ</Label>
                <div className="flex gap-2">
                  <Input
                    id="edit-imageUrl"
                    value={formData.imageUrl}
                    onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                    className="bg-background/50"
                  />
                  <Button variant="outline" size="icon" title="อัปโหลดรูปภาพ">
                    <Upload className="w-4 h-4" />
                  </Button>
                </div>
                {formData.imageUrl && (
                  <div className="mt-2 p-2 border border-white/10 rounded-lg bg-background/30">
                    <img 
                      src={formData.imageUrl} 
                      alt="Preview" 
                      className="w-full h-32 object-cover rounded"
                      onError={(e) => {
                        e.currentTarget.src = "/placeholder-product.png";
                      }}
                    />
                  </div>
                )}
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                ยกเลิก
              </Button>
              <Button onClick={handleEditProduct} className="bg-primary hover:bg-primary/90">
                บันทึกการแก้ไข
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}

