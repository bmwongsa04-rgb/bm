import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Search, 
  Plus, 
  Package, 
  AlertTriangle,
  ShoppingCart,
  Minus
} from "lucide-react";
import { useCart } from "@/contexts/CartContext";
import { toast } from "sonner";
import CartDialog from "@/components/CartDialog";

// Mock Data for Inventory
const inventoryData = [
  { id: 1, name: "น้ำมันเครื่องสังเคราะห์ 5W-30", category: "ของเหลว", stock: 45, price: 1200, status: "มีสินค้า", image: "/placeholder-product.png" },
  { id: 2, name: "ไส้กรองน้ำมันเครื่อง (Toyota)", category: "ไส้กรอง", stock: 12, price: 250, status: "สินค้าใกล้หมด", image: "/placeholder-product.png" },
  { id: 3, name: "ผ้าเบรกหน้า", category: "เบรก", stock: 8, price: 1800, status: "สินค้าใกล้หมด", image: "/placeholder-product.png" },
  { id: 4, name: "หัวเทียน (Iridium)", category: "ระบบจุดระเบิด", stock: 100, price: 350, status: "มีสินค้า", image: "/placeholder-product.png" },
  { id: 5, name: "ไส้กรองอากาศ (Honda)", category: "ไส้กรอง", stock: 0, price: 450, status: "สินค้าหมด", image: "/placeholder-product.png" },
  { id: 6, name: "แบตเตอรี่ 12V 45Ah", category: "ระบบไฟฟ้า", stock: 5, price: 2200, status: "สินค้าใกล้หมด", image: "/placeholder-product.png" },
  { id: 7, name: "ใบปัดน้ำฝน 24 นิ้ว", category: "ภายนอก", stock: 30, price: 300, status: "มีสินค้า", image: "/placeholder-product.png" },
  { id: 8, name: "น้ำยาหล่อเย็น (ผสมเสร็จ)", category: "ของเหลว", stock: 25, price: 180, status: "มีสินค้า", image: "/placeholder-product.png" },
];

export default function Inventory() {
  const [searchTerm, setSearchTerm] = useState("");
  const [cartOpen, setCartOpen] = useState(false);
  const { addToCart, cart, getTotalItems } = useCart();

  const filteredInventory = inventoryData.filter(item => 
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'มีสินค้า': return 'border-emerald-500/50 text-emerald-400 bg-emerald-500/10';
      case 'สินค้าใกล้หมด': return 'border-yellow-500/50 text-yellow-400 bg-yellow-500/10';
      case 'สินค้าหมด': return 'border-destructive/50 text-destructive bg-destructive/10';
      default: return 'border-white/20 text-muted-foreground bg-white/5';
    }
  };

  const handleAddToCart = (product: typeof inventoryData[0]) => {
    if (product.stock === 0) {
      toast.error("สินค้าหมด");
      return;
    }

    const cartItem = cart.find(item => item.productId === product.id);
    if (cartItem && cartItem.quantity >= product.stock) {
      toast.error("เพิ่มสินค้าเกินจำนวนในสต็อกแล้ว");
      return;
    }

    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      stock: product.stock,
    });
    toast.success(`เพิ่ม ${product.name} ลงตะกร้าแล้ว`);
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h2 className="text-3xl font-bold tracking-tight font-display neon-text">คลังสินค้า</h2>
            <p className="text-muted-foreground mt-1">
              เลือกสินค้าและเพิ่มลงตะกร้าเพื่อสั่งซื้อ
            </p>
          </div>
          <Button 
            onClick={() => setCartOpen(true)}
            className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_15px_var(--color-primary)] border-none relative"
          >
            <ShoppingCart className="mr-2 h-4 w-4" /> 
            ตะกร้าสินค้า
            {getTotalItems() > 0 && (
              <span className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">
                {getTotalItems()}
              </span>
            )}
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card className="glass border-primary/20">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="p-3 rounded-xl bg-primary/10 border border-primary/20">
                <Package className="w-8 h-8 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground uppercase tracking-wider">รายการทั้งหมด</p>
                <h3 className="text-2xl font-bold font-display">{inventoryData.length}</h3>
              </div>
            </CardContent>
          </Card>
          <Card className="glass border-yellow-500/20">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="p-3 rounded-xl bg-yellow-500/10 border border-yellow-500/20">
                <AlertTriangle className="w-8 h-8 text-yellow-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground uppercase tracking-wider">สินค้าใกล้หมด</p>
                <h3 className="text-2xl font-bold font-display text-yellow-500">
                  {inventoryData.filter(i => i.status === 'สินค้าใกล้หมด').length}
                </h3>
              </div>
            </CardContent>
          </Card>
          <Card className="glass border-destructive/20">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="p-3 rounded-xl bg-destructive/10 border border-destructive/20">
                <AlertTriangle className="w-8 h-8 text-destructive" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground uppercase tracking-wider">สินค้าหมด</p>
                <h3 className="text-2xl font-bold font-display text-destructive">
                  {inventoryData.filter(i => i.status === 'สินค้าหมด').length}
                </h3>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search */}
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="ค้นหาอะไหล่..." 
            className="pl-9 bg-background/50 border-white/10 focus:border-primary/50 focus:ring-primary/20"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredInventory.map((product) => {
            const cartItem = cart.find(item => item.productId === product.id);
            const quantityInCart = cartItem?.quantity || 0;

            return (
              <Card key={product.id} className="glass border-primary/20 overflow-hidden group hover:border-primary/40 transition-all">
                <div className="aspect-square bg-white/5 flex items-center justify-center border-b border-white/10 relative overflow-hidden">
                  <Package className="w-20 h-20 text-muted-foreground group-hover:text-primary transition-colors" />
                  {product.status === 'สินค้าหมด' && (
                    <div className="absolute inset-0 bg-black/70 flex items-center justify-center">
                      <span className="text-destructive font-bold text-lg">สินค้าหมด</span>
                    </div>
                  )}
                </div>
                <CardContent className="p-4 space-y-3">
                  <div>
                    <h3 className="font-semibold text-foreground line-clamp-2 min-h-[3rem]">{product.name}</h3>
                    <p className="text-xs text-muted-foreground mt-1">{product.category}</p>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-2xl font-bold text-primary">฿{product.price.toLocaleString()}</p>
                      <p className="text-xs text-muted-foreground">คงเหลือ: {product.stock}</p>
                    </div>
                    <Badge variant="outline" className={getStatusColor(product.status)}>
                      {product.status}
                    </Badge>
                  </div>

                  {quantityInCart > 0 && (
                    <div className="text-sm text-primary font-medium">
                      ในตะกร้า: {quantityInCart} ชิ้น
                    </div>
                  )}

                  <Button 
                    onClick={() => handleAddToCart(product)}
                    disabled={product.stock === 0 || quantityInCart >= product.stock}
                    className="w-full bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {product.stock === 0 ? (
                      "สินค้าหมด"
                    ) : quantityInCart >= product.stock ? (
                      "เต็มสต็อกแล้ว"
                    ) : (
                      <>
                        <Plus className="mr-2 h-4 w-4" /> เพิ่มลงตะกร้า
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {filteredInventory.length === 0 && (
          <div className="text-center py-12">
            <Package className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">ไม่พบสินค้าที่ค้นหา</p>
          </div>
        )}
      </div>

      <CartDialog open={cartOpen} onOpenChange={setCartOpen} />
    </DashboardLayout>
  );
}
