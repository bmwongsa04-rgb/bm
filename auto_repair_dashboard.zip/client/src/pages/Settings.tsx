import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  User, 
  Bell, 
  Shield, 
  Palette, 
  Save,
  Store,
  Plus,
  Pencil,
  Trash2,
  Users
} from "lucide-react";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";

interface UserFormData {
  id?: number;
  username: string;
  password: string;
  name: string;
  email: string;
  role: "admin" | "employee" | "member" | "guest";
  phone: string;
  address: string;
  salary: number;
  position: string;
}

export default function Settings() {
  const { user: currentUser } = useAuth();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [formData, setFormData] = useState<UserFormData>({
    username: "",
    password: "",
    name: "",
    email: "",
    role: "employee",
    phone: "",
    address: "",
    salary: 0,
    position: "",
  });

  const { data: users, refetch: refetchUsers } = trpc.auth.getAllUsers.useQuery();
  const createUserMutation = trpc.auth.createUser.useMutation();
  const updateUserMutation = trpc.auth.updateUser.useMutation();
  const deleteUserMutation = trpc.auth.deleteUser.useMutation();

  const handleAddUser = async () => {
    try {
      await createUserMutation.mutateAsync(formData);
      toast.success("เพิ่มผู้ใช้สำเร็จ");
      setIsAddDialogOpen(false);
      refetchUsers();
      resetForm();
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาดในการเพิ่มผู้ใช้");
    }
  };

  const handleEditUser = async () => {
    if (!selectedUser) return;
    
    try {
      const updates: any = { id: selectedUser.id };
      if (formData.username !== selectedUser.username) updates.username = formData.username;
      if (formData.password) updates.password = formData.password;
      if (formData.name !== selectedUser.name) updates.name = formData.name;
      if (formData.email !== selectedUser.email) updates.email = formData.email;
      if (formData.role !== selectedUser.role) updates.role = formData.role;
      if (formData.phone !== selectedUser.phone) updates.phone = formData.phone;
      if (formData.address !== selectedUser.address) updates.address = formData.address;
      if (formData.salary !== selectedUser.salary) updates.salary = formData.salary;
      if (formData.position !== selectedUser.position) updates.position = formData.position;

      await updateUserMutation.mutateAsync(updates);
      toast.success("แก้ไขข้อมูลผู้ใช้สำเร็จ");
      setIsEditDialogOpen(false);
      refetchUsers();
      resetForm();
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาดในการแก้ไขข้อมูล");
    }
  };

  const handleDeleteUser = async () => {
    if (!selectedUser) return;
    
    try {
      await deleteUserMutation.mutateAsync({ id: selectedUser.id });
      toast.success("ลบผู้ใช้สำเร็จ");
      setIsDeleteDialogOpen(false);
      refetchUsers();
      setSelectedUser(null);
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาดในการลบผู้ใช้");
    }
  };

  const openEditDialog = (user: any) => {
    setSelectedUser(user);
    setFormData({
      id: user.id,
      username: user.username,
      password: "",
      name: user.name || "",
      email: user.email || "",
      role: user.role,
      phone: user.phone || "",
      address: user.address || "",
      salary: user.salary || 0,
      position: user.position || "",
    });
    setIsEditDialogOpen(true);
  };

  const openDeleteDialog = (user: any) => {
    setSelectedUser(user);
    setIsDeleteDialogOpen(true);
  };

  const resetForm = () => {
    setFormData({
      username: "",
      password: "",
      name: "",
      email: "",
      role: "employee",
      phone: "",
      address: "",
      salary: 0,
      position: "",
    });
    setSelectedUser(null);
  };

  const isAdmin = currentUser?.role === "admin";

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h2 className="text-3xl font-bold tracking-tight font-display neon-text">ตั้งค่าระบบ</h2>
          <p className="text-muted-foreground mt-1">
            จัดการข้อมูลส่วนตัว, การแจ้งเตือน และการตั้งค่าทั่วไป
          </p>
        </div>

        <Tabs defaultValue="general" className="space-y-6">
          <TabsList className="bg-card/50 border border-white/10 p-1">
            <TabsTrigger value="general" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <Store className="w-4 h-4 mr-2" /> ทั่วไป
            </TabsTrigger>
            <TabsTrigger value="account" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <User className="w-4 h-4 mr-2" /> บัญชีผู้ใช้
            </TabsTrigger>
            {isAdmin && (
              <TabsTrigger value="users" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                <Users className="w-4 h-4 mr-2" /> จัดการผู้ใช้
              </TabsTrigger>
            )}
            <TabsTrigger value="notifications" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <Bell className="w-4 h-4 mr-2" /> การแจ้งเตือน
            </TabsTrigger>
            <TabsTrigger value="appearance" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <Palette className="w-4 h-4 mr-2" /> การแสดงผล
            </TabsTrigger>
          </TabsList>

          {/* General Settings */}
          <TabsContent value="general">
            <Card className="glass border-primary/20">
              <CardHeader>
                <CardTitle>ข้อมูลร้านค้า</CardTitle>
                <CardDescription>จัดการข้อมูลพื้นฐานของอู่ซ่อมรถของคุณ</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="shop-name">ชื่อร้าน</Label>
                    <Input id="shop-name" placeholder="NEO-FIX Auto Service" className="bg-background/50" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="shop-phone">เบอร์โทรศัพท์</Label>
                    <Input id="shop-phone" placeholder="02-XXX-XXXX" className="bg-background/50" />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="shop-address">ที่อยู่</Label>
                    <Input id="shop-address" placeholder="123 ถนนสุขุมวิท กรุงเทพฯ" className="bg-background/50" />
                  </div>
                </div>
                <Button className="bg-primary hover:bg-primary/90">
                  <Save className="w-4 h-4 mr-2" />
                  บันทึกการเปลี่ยนแปลง
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Account Settings */}
          <TabsContent value="account">
            <Card className="glass border-primary/20">
              <CardHeader>
                <CardTitle>ข้อมูลบัญชีผู้ใช้</CardTitle>
                <CardDescription>แก้ไขข้อมูลส่วนตัวและรหัสผ่านของคุณ</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="username">ชื่อผู้ใช้</Label>
                    <Input id="username" value={currentUser?.username || ""} disabled className="bg-background/30" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="role">บทบาท</Label>
                    <Input id="role" value={currentUser?.role || ""} disabled className="bg-background/30" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="name">ชื่อ-นามสกุล</Label>
                    <Input id="name" placeholder="ชื่อ-นามสกุล" className="bg-background/50" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">อีเมล</Label>
                    <Input id="email" type="email" placeholder="example@email.com" className="bg-background/50" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="new-password">รหัสผ่านใหม่</Label>
                    <Input id="new-password" type="password" placeholder="••••••••" className="bg-background/50" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirm-password">ยืนยันรหัสผ่าน</Label>
                    <Input id="confirm-password" type="password" placeholder="••••••••" className="bg-background/50" />
                  </div>
                </div>
                <Button className="bg-primary hover:bg-primary/90">
                  <Save className="w-4 h-4 mr-2" />
                  บันทึกการเปลี่ยนแปลง
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* User Management (Admin Only) */}
          {isAdmin && (
            <TabsContent value="users">
              <Card className="glass border-primary/20">
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle>จัดการผู้ใช้</CardTitle>
                    <CardDescription>เพิ่ม แก้ไข หรือลบข้อมูลพนักงานและผู้ใช้ในระบบ</CardDescription>
                  </div>
                  <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                    <DialogTrigger asChild>
                      <Button className="bg-primary hover:bg-primary/90">
                        <Plus className="w-4 h-4 mr-2" />
                        เพิ่มผู้ใช้
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl glass border-primary/20">
                      <DialogHeader>
                        <DialogTitle>เพิ่มผู้ใช้ใหม่</DialogTitle>
                        <DialogDescription>กรอกข้อมูลผู้ใช้ใหม่ในระบบ</DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="add-username">ชื่อผู้ใช้ *</Label>
                            <Input
                              id="add-username"
                              value={formData.username}
                              onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                              className="bg-background/50"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="add-password">รหัสผ่าน *</Label>
                            <Input
                              id="add-password"
                              type="password"
                              value={formData.password}
                              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                              className="bg-background/50"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="add-name">ชื่อ-นามสกุล</Label>
                            <Input
                              id="add-name"
                              value={formData.name}
                              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                              className="bg-background/50"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="add-email">อีเมล</Label>
                            <Input
                              id="add-email"
                              type="email"
                              value={formData.email}
                              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                              className="bg-background/50"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="add-role">บทบาท *</Label>
                            <Select value={formData.role} onValueChange={(value: any) => setFormData({ ...formData, role: value })}>
                              <SelectTrigger className="bg-background/50">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="admin">ผู้ดูแลระบบ</SelectItem>
                                <SelectItem value="employee">พนักงาน</SelectItem>
                                <SelectItem value="member">สมาชิก</SelectItem>
                                <SelectItem value="guest">ผู้เยี่ยมชม</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="add-phone">เบอร์โทรศัพท์</Label>
                            <Input
                              id="add-phone"
                              value={formData.phone}
                              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                              className="bg-background/50"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="add-position">ตำแหน่ง</Label>
                            <Input
                              id="add-position"
                              value={formData.position}
                              onChange={(e) => setFormData({ ...formData, position: e.target.value })}
                              className="bg-background/50"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="add-salary">เงินเดือน (บาท)</Label>
                            <Input
                              id="add-salary"
                              type="number"
                              value={formData.salary}
                              onChange={(e) => setFormData({ ...formData, salary: parseFloat(e.target.value) || 0 })}
                              className="bg-background/50"
                            />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="add-address">ที่อยู่</Label>
                          <Input
                            id="add-address"
                            value={formData.address}
                            onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                            className="bg-background/50"
                          />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button variant="outline" onClick={() => { setIsAddDialogOpen(false); resetForm(); }}>
                          ยกเลิก
                        </Button>
                        <Button onClick={handleAddUser} className="bg-primary hover:bg-primary/90">
                          เพิ่มผู้ใช้
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </CardHeader>
                <CardContent>
                  <div className="rounded-lg border border-white/10 overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow className="border-white/10 hover:bg-white/5">
                          <TableHead>ชื่อผู้ใช้</TableHead>
                          <TableHead>ชื่อ-นามสกุล</TableHead>
                          <TableHead>บทบาท</TableHead>
                          <TableHead>ตำแหน่ง</TableHead>
                          <TableHead className="text-right">เงินเดือน</TableHead>
                          <TableHead className="text-right">จัดการ</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {users?.map((user) => (
                          <TableRow key={user.id} className="border-white/10 hover:bg-white/5">
                            <TableCell className="font-medium">{user.username}</TableCell>
                            <TableCell>{user.name || "-"}</TableCell>
                            <TableCell>
                              <span className={`px-2 py-1 rounded-full text-xs ${
                                user.role === "admin" ? "bg-red-500/20 text-red-400" :
                                user.role === "employee" ? "bg-blue-500/20 text-blue-400" :
                                "bg-gray-500/20 text-gray-400"
                              }`}>
                                {user.role === "admin" ? "ผู้ดูแลระบบ" :
                                 user.role === "employee" ? "พนักงาน" :
                                 user.role === "member" ? "สมาชิก" : "ผู้เยี่ยมชม"}
                              </span>
                            </TableCell>
                            <TableCell>{user.position || "-"}</TableCell>
                            <TableCell className="text-right">
                              {user.salary ? `฿${user.salary.toLocaleString()}` : "-"}
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => openEditDialog(user)}
                                  className="border-primary/30 hover:bg-primary/20"
                                >
                                  <Pencil className="w-4 h-4" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => openDeleteDialog(user)}
                                  className="border-red-500/30 hover:bg-red-500/20 text-red-400"
                                  disabled={user.id === currentUser?.id}
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          )}

          {/* Notifications Settings */}
          <TabsContent value="notifications">
            <Card className="glass border-primary/20">
              <CardHeader>
                <CardTitle>การแจ้งเตือน</CardTitle>
                <CardDescription>จัดการการแจ้งเตือนและการส่งข้อความ</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>แจ้งเตือนงานซ่อมใหม่</Label>
                    <p className="text-sm text-muted-foreground">รับการแจ้งเตือนเมื่อมีงานซ่อมใหม่เข้ามา</p>
                  </div>
                  <Switch />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>แจ้งเตือนอะไหล่ใกล้หมด</Label>
                    <p className="text-sm text-muted-foreground">รับการแจ้งเตือนเมื่อสินค้าคงคลังใกล้หมด</p>
                  </div>
                  <Switch />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>แจ้งเตือนนัดหมาย</Label>
                    <p className="text-sm text-muted-foreground">รับการแจ้งเตือนก่อนถึงเวลานัดหมาย 1 ชั่วโมง</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <Button className="bg-primary hover:bg-primary/90">
                  <Save className="w-4 h-4 mr-2" />
                  บันทึกการเปลี่ยนแปลง
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Appearance Settings */}
          <TabsContent value="appearance">
            <Card className="glass border-primary/20">
              <CardHeader>
                <CardTitle>การแสดงผล</CardTitle>
                <CardDescription>ปรับแต่งรูปลักษณ์และธีมของระบบ</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label>ธีมสี</Label>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="relative cursor-pointer rounded-lg border-2 border-primary p-4 bg-gradient-to-br from-cyan-500/20 to-blue-500/20">
                      <div className="absolute top-2 right-2 w-4 h-4 rounded-full bg-primary"></div>
                      <p className="text-sm font-medium">Neon Garage (ปัจจุบัน)</p>
                    </div>
                    <div className="cursor-pointer rounded-lg border border-white/10 p-4 bg-gradient-to-br from-purple-500/20 to-pink-500/20 hover:border-white/30">
                      <p className="text-sm font-medium">Cyber Purple</p>
                    </div>
                    <div className="cursor-pointer rounded-lg border border-white/10 p-4 bg-gradient-to-br from-green-500/20 to-emerald-500/20 hover:border-white/30">
                      <p className="text-sm font-medium">Matrix Green</p>
                    </div>
                  </div>
                </div>
                <Button className="bg-primary hover:bg-primary/90">
                  <Save className="w-4 h-4 mr-2" />
                  บันทึกการเปลี่ยนแปลง
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Edit User Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl glass border-primary/20">
          <DialogHeader>
            <DialogTitle>แก้ไขข้อมูลผู้ใช้</DialogTitle>
            <DialogDescription>แก้ไขข้อมูลของ {selectedUser?.username}</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-username">ชื่อผู้ใช้</Label>
                <Input
                  id="edit-username"
                  value={formData.username}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  className="bg-background/50"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-password">รหัสผ่านใหม่ (เว้นว่างถ้าไม่เปลี่ยน)</Label>
                <Input
                  id="edit-password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="bg-background/50"
                  placeholder="••••••••"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">ชื่อ-นามสกุล</Label>
                <Input
                  id="edit-name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="bg-background/50"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-email">อีเมล</Label>
                <Input
                  id="edit-email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="bg-background/50"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-role">บทบาท</Label>
                <Select value={formData.role} onValueChange={(value: any) => setFormData({ ...formData, role: value })}>
                  <SelectTrigger className="bg-background/50">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">ผู้ดูแลระบบ</SelectItem>
                    <SelectItem value="employee">พนักงาน</SelectItem>
                    <SelectItem value="member">สมาชิก</SelectItem>
                    <SelectItem value="guest">ผู้เยี่ยมชม</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-phone">เบอร์โทรศัพท์</Label>
                <Input
                  id="edit-phone"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="bg-background/50"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-position">ตำแหน่ง</Label>
                <Input
                  id="edit-position"
                  value={formData.position}
                  onChange={(e) => setFormData({ ...formData, position: e.target.value })}
                  className="bg-background/50"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-salary">เงินเดือน (บาท)</Label>
                <Input
                  id="edit-salary"
                  type="number"
                  value={formData.salary}
                  onChange={(e) => setFormData({ ...formData, salary: parseFloat(e.target.value) || 0 })}
                  className="bg-background/50"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-address">ที่อยู่</Label>
              <Input
                id="edit-address"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className="bg-background/50"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setIsEditDialogOpen(false); resetForm(); }}>
              ยกเลิก
            </Button>
            <Button onClick={handleEditUser} className="bg-primary hover:bg-primary/90">
              บันทึกการเปลี่ยนแปลง
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent className="glass border-primary/20">
          <AlertDialogHeader>
            <AlertDialogTitle>ยืนยันการลบผู้ใช้</AlertDialogTitle>
            <AlertDialogDescription>
              คุณแน่ใจหรือไม่ว่าต้องการลบผู้ใช้ <span className="font-semibold text-primary">{selectedUser?.username}</span>?
              การกระทำนี้ไม่สามารถย้อนกลับได้
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => { setIsDeleteDialogOpen(false); setSelectedUser(null); }}>
              ยกเลิก
            </AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteUser} className="bg-red-500 hover:bg-red-600">
              ลบผู้ใช้
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashboardLayout>
  );
}
