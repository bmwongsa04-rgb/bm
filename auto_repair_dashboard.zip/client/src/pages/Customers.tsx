import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { 
  Search, 
  Plus, 
  User, 
  Phone,
  Mail,
  Car,
  MapPin,
  Pencil,
  Trash2,
  Eye,
  Wrench,
  Calendar
} from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

interface CustomerFormData {
  id?: number;
  name: string;
  phone: string;
  email: string;
  address: string;
}

export default function Customers() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [formData, setFormData] = useState<CustomerFormData>({
    name: "",
    phone: "",
    email: "",
    address: "",
  });

  const { data: customers, refetch: refetchCustomers } = trpc.customers.getAll.useQuery();
  const createCustomerMutation = trpc.customers.create.useMutation();
  const updateCustomerMutation = trpc.customers.update.useMutation();
  const deleteCustomerMutation = trpc.customers.delete.useMutation();

  // Query for selected customer's vehicles and repairs
  const { data: customerVehicles } = trpc.customers.getVehicles.useQuery(
    { customerId: selectedCustomer?.id || 0 },
    { enabled: !!selectedCustomer }
  );
  const { data: customerRepairs } = trpc.customers.getRepairHistory.useQuery(
    { customerId: selectedCustomer?.id || 0 },
    { enabled: !!selectedCustomer }
  );

  const filteredCustomers = customers?.filter(customer => 
    customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.phone.includes(searchTerm) ||
    (customer.email && customer.email.toLowerCase().includes(searchTerm.toLowerCase()))
  ) || [];

  const handleAddCustomer = async () => {
    try {
      await createCustomerMutation.mutateAsync(formData);
      toast.success("เพิ่มลูกค้าสำเร็จ");
      setIsAddDialogOpen(false);
      refetchCustomers();
      resetForm();
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาดในการเพิ่มลูกค้า");
    }
  };

  const handleEditCustomer = async () => {
    if (!selectedCustomer) return;
    try {
      await updateCustomerMutation.mutateAsync({
        id: selectedCustomer.id,
        ...formData,
      });
      toast.success("แก้ไขลูกค้าสำเร็จ");
      setIsEditDialogOpen(false);
      refetchCustomers();
      resetForm();
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาดในการแก้ไขลูกค้า");
    }
  };

  const handleDeleteCustomer = async (id: number) => {
    if (!confirm("คุณแน่ใจหรือไม่ที่จะลบลูกค้านี้?")) return;
    try {
      await deleteCustomerMutation.mutateAsync({ id });
      toast.success("ลบลูกค้าสำเร็จ");
      refetchCustomers();
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาดในการลบลูกค้า");
    }
  };

  const resetForm = () => {
    setFormData({
      name: "",
      phone: "",
      email: "",
      address: "",
    });
    setSelectedCustomer(null);
  };

  const openEditDialog = (customer: any) => {
    setSelectedCustomer(customer);
    setFormData({
      name: customer.name,
      phone: customer.phone,
      email: customer.email || "",
      address: customer.address || "",
    });
    setIsEditDialogOpen(true);
  };

  const openViewDialog = (customer: any) => {
    setSelectedCustomer(customer);
    setIsViewDialogOpen(true);
  };

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-display font-bold tracking-wider text-foreground">
              ข้อมูลลูกค้า
            </h1>
            <p className="text-muted-foreground mt-1">
              จัดการฐานข้อมูลลูกค้าและประวัติการใช้บริการ
            </p>
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-primary/90">
                <Plus className="w-4 h-4 mr-2" />
                เพิ่มลูกค้าใหม่
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl glass border-primary/20">
              <DialogHeader>
                <DialogTitle>เพิ่มลูกค้าใหม่</DialogTitle>
                <DialogDescription>กรอกข้อมูลลูกค้าที่ต้องการเพิ่มเข้าระบบ</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="add-name">ชื่อ-นามสกุล *</Label>
                    <Input
                      id="add-name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="เช่น สมชาย ใจดี"
                      className="bg-background/50"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="add-phone">เบอร์โทรศัพท์ *</Label>
                    <Input
                      id="add-phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="081-234-5678"
                      className="bg-background/50"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="add-email">อีเมล</Label>
                  <Input
                    id="add-email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="example@email.com"
                    className="bg-background/50"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="add-address">ที่อยู่</Label>
                  <Input
                    id="add-address"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    placeholder="123 ถนนสุขุมวิท กรุงเทพฯ"
                    className="bg-background/50"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  ยกเลิก
                </Button>
                <Button onClick={handleAddCustomer} className="bg-primary hover:bg-primary/90">
                  เพิ่มลูกค้า
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="ค้นหาลูกค้าด้วยชื่อ เบอร์โทร หรืออีเมล..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-background/50 border-white/10"
          />
        </div>

        {/* Customers Table */}
        <Card className="glass border-primary/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="w-5 h-5" />
              รายชื่อลูกค้าทั้งหมด
            </CardTitle>
            <CardDescription>
              จำนวนลูกค้าทั้งหมด: {customers?.length || 0} คน
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow className="border-white/10 hover:bg-white/5">
                  <TableHead>ชื่อ-นามสกุล</TableHead>
                  <TableHead>เบอร์โทรศัพท์</TableHead>
                  <TableHead>อีเมล</TableHead>
                  <TableHead>ที่อยู่</TableHead>
                  <TableHead className="text-right">จัดการ</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCustomers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                      <User className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      ไม่พบข้อมูลลูกค้า
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredCustomers.map((customer) => (
                    <TableRow key={customer.id} className="border-white/10 hover:bg-white/5">
                      <TableCell className="font-medium">{customer.name}</TableCell>
                      <TableCell className="font-mono">{customer.phone}</TableCell>
                      <TableCell className="text-muted-foreground">{customer.email || "-"}</TableCell>
                      <TableCell className="text-muted-foreground max-w-xs truncate">{customer.address || "-"}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => openViewDialog(customer)}
                            className="hover:bg-primary/20 hover:text-primary"
                            title="ดูรายละเอียด"
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => openEditDialog(customer)}
                            className="hover:bg-primary/20 hover:text-primary"
                            title="แก้ไข"
                          >
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDeleteCustomer(customer.id)}
                            className="hover:bg-destructive/20 hover:text-destructive"
                            title="ลบ"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Edit Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="max-w-2xl glass border-primary/20">
            <DialogHeader>
              <DialogTitle>แก้ไขข้อมูลลูกค้า</DialogTitle>
              <DialogDescription>แก้ไขข้อมูลลูกค้าในระบบ</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-name">ชื่อ-นามสกุล *</Label>
                  <Input
                    id="edit-name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="bg-background/50"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-phone">เบอร์โทรศัพท์ *</Label>
                  <Input
                    id="edit-phone"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="bg-background/50"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-email">อีเมล</Label>
                <Input
                  id="edit-email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="bg-background/50"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-address">ที่อยู่</Label>
                <Input
                  id="edit-address"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="bg-background/50"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                ยกเลิก
              </Button>
              <Button onClick={handleEditCustomer} className="bg-primary hover:bg-primary/90">
                บันทึกการแก้ไข
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* View Customer Details Dialog */}
        <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
          <DialogContent className="max-w-4xl glass border-primary/20">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <User className="w-5 h-5" />
                รายละเอียดลูกค้า: {selectedCustomer?.name}
              </DialogTitle>
              <DialogDescription>ข้อมูลลูกค้า รถ และประวัติการซ่อม</DialogDescription>
            </DialogHeader>
            <Tabs defaultValue="info" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="info">ข้อมูลลูกค้า</TabsTrigger>
                <TabsTrigger value="vehicles">รถของลูกค้า</TabsTrigger>
                <TabsTrigger value="repairs">ประวัติการซ่อม</TabsTrigger>
              </TabsList>
              <TabsContent value="info" className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-background/30 border border-white/10">
                    <User className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-xs text-muted-foreground">ชื่อ-นามสกุล</p>
                      <p className="font-medium">{selectedCustomer?.name}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-background/30 border border-white/10">
                    <Phone className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-xs text-muted-foreground">เบอร์โทรศัพท์</p>
                      <p className="font-medium font-mono">{selectedCustomer?.phone}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-background/30 border border-white/10">
                    <Mail className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-xs text-muted-foreground">อีเมล</p>
                      <p className="font-medium">{selectedCustomer?.email || "-"}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-background/30 border border-white/10">
                    <MapPin className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-xs text-muted-foreground">ที่อยู่</p>
                      <p className="font-medium">{selectedCustomer?.address || "-"}</p>
                    </div>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="vehicles">
                <div className="space-y-3">
                  {!customerVehicles || customerVehicles.length === 0 ? (
                    <div className="text-center text-muted-foreground py-8">
                      <Car className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      <p>ยังไม่มีข้อมูลรถของลูกค้า</p>
                    </div>
                  ) : (
                    customerVehicles.map((vehicle: any) => (
                      <div key={vehicle.id} className="flex items-center gap-3 p-3 rounded-lg bg-background/30 border border-white/10">
                        <Car className="w-5 h-5 text-primary" />
                        <div className="flex-1">
                          <p className="font-medium">{vehicle.licensePlate}</p>
                          <p className="text-sm text-muted-foreground">{vehicle.brand} {vehicle.model} ({vehicle.year})</p>
                        </div>
                        <Badge variant="outline" className="border-primary/50 text-primary">
                          {vehicle.color}
                        </Badge>
                      </div>
                    ))
                  )}
                </div>
              </TabsContent>
              <TabsContent value="repairs">
                <div className="space-y-3">
                  {!customerRepairs || customerRepairs.length === 0 ? (
                    <div className="text-center text-muted-foreground py-8">
                      <Wrench className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      <p>ยังไม่มีประวัติการซ่อม</p>
                    </div>
                  ) : (
                    customerRepairs.map((repair: any) => (
                      <div key={repair.id} className="flex items-start gap-3 p-3 rounded-lg bg-background/30 border border-white/10">
                        <Wrench className="w-5 h-5 text-primary mt-0.5" />
                        <div className="flex-1">
                          <p className="font-medium">{repair.repairCode}</p>
                          <p className="text-sm text-muted-foreground">{repair.description}</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            <Calendar className="w-3 h-3 inline mr-1" />
                            {new Date(repair.createdAt).toLocaleDateString('th-TH')}
                          </p>
                        </div>
                        <div className="text-right">
                          <Badge variant="outline" className={
                            repair.status === 'completed' ? 'border-emerald-500/50 text-emerald-400' :
                            repair.status === 'in_progress' ? 'border-yellow-500/50 text-yellow-400' :
                            'border-white/20 text-muted-foreground'
                          }>
                            {repair.status === 'completed' ? 'เสร็จสิ้น' :
                             repair.status === 'in_progress' ? 'กำลังดำเนินการ' :
                             repair.status === 'pending' ? 'รอดำเนินการ' : 'ยกเลิก'}
                          </Badge>
                          <p className="text-sm font-mono mt-1">฿{repair.estimatedCost?.toLocaleString() || 0}</p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
