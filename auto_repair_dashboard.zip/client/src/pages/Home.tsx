import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import DashboardLayout from "@/components/DashboardLayout";
import { 
  Area, 
  AreaChart, 
  Bar, 
  BarChart, 
  CartesianGrid, 
  Cell, 
  Legend, 
  Line, 
  LineChart, 
  Pie, 
  PieChart, 
  ResponsiveContainer, 
  Tooltip, 
  XAxis, 
  YAxis 
} from "recharts";
import { 
  ArrowUpRight, 
  ArrowDownRight, 
  DollarSign, 
  Car, 
  Wrench, 
  CheckCircle2, 
  Clock,
  AlertTriangle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

// Mock Data
const revenueData = [
  { name: "ม.ค.", total: 15000 },
  { name: "ก.พ.", total: 18000 },
  { name: "มี.ค.", total: 22000 },
  { name: "เม.ย.", total: 28000 },
  { name: "พ.ค.", total: 25000 },
  { name: "มิ.ย.", total: 32000 },
  { name: "ก.ค.", total: 38000 },
];

const serviceTypeData = [
  { name: "บำรุงรักษา", value: 45, color: "var(--chart-1)" },
  { name: "ซ่อมแซม", value: 30, color: "var(--chart-2)" },
  { name: "อะไหล่", value: 15, color: "var(--chart-3)" },
  { name: "ตรวจเช็ค", value: 10, color: "var(--chart-4)" },
];

const recentRepairs = [
  { id: "R-1024", car: "Toyota Camry", plate: "1AB-2345", status: "In Progress", date: "2023-10-24", amount: 4500 },
  { id: "R-1023", car: "Honda Civic", plate: "9XY-8765", status: "Completed", date: "2023-10-23", amount: 2800 },
  { id: "R-1022", car: "Mazda 3", plate: "4CD-5678", status: "Pending", date: "2023-10-23", amount: 1200 },
  { id: "R-1021", car: "Isuzu D-Max", plate: "2EF-9012", status: "Completed", date: "2023-10-22", amount: 8500 },
  { id: "R-1020", car: "Ford Ranger", plate: "7GH-3456", status: "Cancelled", date: "2023-10-21", amount: 0 },
];

const StatCard = ({ title, value, change, icon: Icon, trend }: any) => (
  <Card className="glass overflow-hidden relative group">
    <div className="absolute -right-6 -top-6 w-24 h-24 bg-primary/10 rounded-full blur-2xl group-hover:bg-primary/20 transition-all duration-500" />
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
        {title}
      </CardTitle>
      <div className="p-2 rounded-lg bg-white/5 border border-white/10 group-hover:border-primary/50 transition-colors">
        <Icon className="h-4 w-4 text-primary" />
      </div>
    </CardHeader>
    <CardContent>
      <div className="text-3xl font-bold font-display tracking-tight neon-text">{value}</div>
      <p className={`text-xs flex items-center mt-1 ${trend === 'up' ? 'text-emerald-400' : 'text-rose-400'}`}>
        {trend === 'up' ? <ArrowUpRight className="w-3 h-3 mr-1" /> : <ArrowDownRight className="w-3 h-3 mr-1" />}
        <span className="font-bold">{change}</span>
        <span className="text-muted-foreground ml-1">จากเดือนที่แล้ว</span>
      </p>
    </CardContent>
  </Card>
);

export default function Home() {
  // The userAuth hooks provides authentication state
  // To implement login/logout functionality, simply call logout() or redirect to getLoginUrl()
  let { user, loading, error, isAuthenticated, logout } = useAuth();

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header Section */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h2 className="text-3xl font-bold tracking-tight font-display neon-text">ภาพรวมระบบ</h2>
            <p className="text-muted-foreground mt-1">
              ยินดีต้อนรับกลับ, ผู้ดูแลระบบ นี่คือสถานะอู่ซ่อมรถของคุณในวันนี้
            </p>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" className="glass hover:bg-white/10 border-primary/30 text-primary hover:text-primary">
              <Clock className="mr-2 h-4 w-4" /> ประวัติ
            </Button>
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_15px_var(--color-primary)] border-none">
              <Wrench className="mr-2 h-4 w-4" /> เปิดงานซ่อมใหม่
            </Button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <StatCard 
            title="รายได้รวม" 
            value="฿452,318" 
            change="+20.1%" 
            icon={DollarSign} 
            trend="up" 
          />
          <StatCard 
            title="งานซ่อมที่กำลังทำ" 
            value="12" 
            change="+4" 
            icon={Car} 
            trend="up" 
          />
          <StatCard 
            title="งานที่เสร็จสิ้น" 
            value="145" 
            change="+12.5%" 
            icon={CheckCircle2} 
            trend="up" 
          />
          <StatCard 
            title="รออะไหล่" 
            value="3" 
            change="-2" 
            icon={AlertTriangle} 
            trend="down" 
          />
        </div>

        {/* Main Charts Section */}
        <div className="grid gap-4 md:grid-cols-7">
          {/* Revenue Chart */}
          <Card className="col-span-4 glass border-primary/20">
            <CardHeader>
              <CardTitle className="font-display tracking-wide">ภาพรวมรายได้</CardTitle>
              <CardDescription>ผลประกอบการรายเดือนสำหรับปีปัจจุบัน</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={revenueData}>
                    <defs>
                      <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="var(--color-primary)" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="var(--color-primary)" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" vertical={false} />
                    <XAxis 
                      dataKey="name" 
                      stroke="#888888" 
                      fontSize={12} 
                      tickLine={false} 
                      axisLine={false} 
                    />
                    <YAxis 
                      stroke="#888888" 
                      fontSize={12} 
                      tickLine={false} 
                      axisLine={false} 
                      tickFormatter={(value) => `฿${value/1000}k`} 
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'rgba(20, 20, 30, 0.9)', 
                        border: '1px solid rgba(255,255,255,0.1)',
                        borderRadius: '8px',
                        boxShadow: '0 0 10px rgba(0,0,0,0.5)'
                      }}
                      itemStyle={{ color: '#fff' }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="total" 
                      stroke="var(--color-primary)" 
                      strokeWidth={3}
                      fillOpacity={1} 
                      fill="url(#colorTotal)" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Service Distribution Chart */}
          <Card className="col-span-3 glass border-primary/20">
            <CardHeader>
              <CardTitle className="font-display tracking-wide">สัดส่วนการบริการ</CardTitle>
              <CardDescription>แยกตามประเภทงานบริการในเดือนนี้</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full relative">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={serviceTypeData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                      stroke="none"
                    >
                      {serviceTypeData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'rgba(20, 20, 30, 0.9)', 
                        border: '1px solid rgba(255,255,255,0.1)',
                        borderRadius: '8px'
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center">
                  <div className="text-2xl font-bold font-display">100%</div>
                  <div className="text-xs text-muted-foreground">บริการ</div>
                </div>
              </div>
              <div className="flex justify-center gap-4 mt-[-20px]">
                {serviceTypeData.map((item, index) => (
                  <div key={index} className="flex items-center gap-1.5">
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                    <span className="text-xs text-muted-foreground">{item.name}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Repairs Table */}
        <Card className="glass border-primary/20">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="font-display tracking-wide">งานซ่อมล่าสุด</CardTitle>
              <CardDescription>ยานพาหนะล่าสุดที่เข้ารับบริการในระบบ</CardDescription>
            </div>
            <Button variant="ghost" size="sm" className="text-primary hover:text-primary hover:bg-primary/10">
              ดูทั้งหมด
            </Button>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="text-xs text-muted-foreground uppercase bg-white/5 border-b border-white/10">
                  <tr>
                    <th className="px-4 py-3 rounded-tl-lg">รหัสงาน</th>
                    <th className="px-4 py-3">ยานพาหนะ</th>
                    <th className="px-4 py-3">ทะเบียน</th>
                    <th className="px-4 py-3">วันที่</th>
                    <th className="px-4 py-3">ยอดเงิน</th>
                    <th className="px-4 py-3 rounded-tr-lg">สถานะ</th>
                  </tr>
                </thead>
                <tbody>
                  {recentRepairs.map((job, index) => (
                    <tr key={job.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                      <td className="px-4 py-3 font-mono text-primary">{job.id}</td>
                      <td className="px-4 py-3 font-medium">{job.car}</td>
                      <td className="px-4 py-3 text-muted-foreground">{job.plate}</td>
                      <td className="px-4 py-3 text-muted-foreground">{job.date}</td>
                      <td className="px-4 py-3 font-mono">฿{job.amount.toLocaleString()}</td>
                      <td className="px-4 py-3">
                        <Badge 
                          variant="outline" 
                          className={`
                            ${job.status === 'Completed' ? 'border-emerald-500/50 text-emerald-400 bg-emerald-500/10' : ''}
                            ${job.status === 'In Progress' ? 'border-blue-500/50 text-blue-400 bg-blue-500/10' : ''}
                            ${job.status === 'Pending' ? 'border-yellow-500/50 text-yellow-400 bg-yellow-500/10' : ''}
                            ${job.status === 'Cancelled' ? 'border-red-500/50 text-red-400 bg-red-500/10' : ''}
                          `}
                        >
                          {job.status}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
