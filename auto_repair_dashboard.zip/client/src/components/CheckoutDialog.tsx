import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useCart } from "@/contexts/CartContext";
import { useAuth } from "@/contexts/AuthContext";
import { CreditCard, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { useState } from "react";

interface CheckoutDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

export default function CheckoutDialog({ open, onOpenChange, onSuccess }: CheckoutDialogProps) {
  const { cart, getTotalPrice, clearCart } = useCart();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [formData, setFormData] = useState({
    customerName: user?.name || "",
    phone: user?.phone || "",
    address: "",
    notes: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));

      // Create order data
      const orderData = {
        customer: formData,
        items: cart,
        total: getTotalPrice(),
        orderDate: new Date().toISOString(),
        status: "pending",
      };

      console.log("Order created:", orderData);

      // Clear cart and show success
      clearCart();
      setSuccess(true);
      toast.success("สั่งซื้อสำเร็จ!");

      // Reset form after 2 seconds
      setTimeout(() => {
        setSuccess(false);
        setFormData({
          customerName: user?.name || "",
          phone: user?.phone || "",
          address: "",
          notes: "",
        });
        onSuccess();
      }, 2000);
    } catch (error) {
      toast.error("เกิดข้อผิดพลาดในการสั่งซื้อ");
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  if (success) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-[500px] glass border-primary/30">
          <div className="text-center py-8">
            <div className="mx-auto w-20 h-20 rounded-full bg-emerald-500/20 flex items-center justify-center border-2 border-emerald-500 mb-6">
              <CheckCircle2 className="w-12 h-12 text-emerald-500" />
            </div>
            <h3 className="text-2xl font-bold font-display neon-text mb-2">สั่งซื้อสำเร็จ!</h3>
            <p className="text-muted-foreground">
              คำสั่งซื้อของคุณได้รับการบันทึกแล้ว
            </p>
            <p className="text-sm text-muted-foreground mt-2">
              เราจะติดต่อกลับไปเร็วๆ นี้
            </p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] glass border-primary/30 max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-2xl font-display neon-text">
            <CreditCard className="w-6 h-6" />
            ชำระเงิน
          </DialogTitle>
          <DialogDescription>
            กรอกข้อมูลเพื่อยืนยันการสั่งซื้อ
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          {/* Order Summary */}
          <div className="bg-card/30 p-4 rounded-lg border border-white/10 space-y-2">
            <h4 className="font-semibold text-foreground mb-3">สรุปคำสั่งซื้อ</h4>
            {cart.map((item) => (
              <div key={item.id} className="flex justify-between text-sm">
                <span className="text-muted-foreground">
                  {item.productName} x {item.quantity}
                </span>
                <span className="font-mono text-foreground">
                  ฿{(item.price * item.quantity).toLocaleString()}
                </span>
              </div>
            ))}
            <div className="border-t border-white/10 pt-2 mt-2 flex justify-between font-semibold">
              <span>ยอดรวมทั้งหมด:</span>
              <span className="text-xl text-primary font-display">
                ฿{getTotalPrice().toLocaleString()}
              </span>
            </div>
          </div>

          {/* Customer Information */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="customerName">ชื่อ-นามสกุล *</Label>
              <Input
                id="customerName"
                name="customerName"
                value={formData.customerName}
                onChange={handleChange}
                required
                className="bg-background/50 border-white/10"
                placeholder="กรอกชื่อ-นามสกุล"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">เบอร์โทรศัพท์ *</Label>
              <Input
                id="phone"
                name="phone"
                type="tel"
                value={formData.phone}
                onChange={handleChange}
                required
                className="bg-background/50 border-white/10"
                placeholder="กรอกเบอร์โทรศัพท์"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="address">ที่อยู่จัดส่ง *</Label>
              <Textarea
                id="address"
                name="address"
                value={formData.address}
                onChange={handleChange}
                required
                className="bg-background/50 border-white/10 min-h-[100px]"
                placeholder="กรอกที่อยู่สำหรับจัดส่งสินค้า"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">หมายเหตุ (ถ้ามี)</Label>
              <Textarea
                id="notes"
                name="notes"
                value={formData.notes}
                onChange={handleChange}
                className="bg-background/50 border-white/10"
                placeholder="ข้อความเพิ่มเติม..."
              />
            </div>
          </div>

          <DialogFooter className="flex gap-2">
            <Button
              type="button"
              variant="outline"
              className="flex-1 border-white/10 hover:bg-white/5"
              onClick={() => onOpenChange(false)}
              disabled={loading}
            >
              ยกเลิก
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_15px_var(--color-primary)]"
              disabled={loading}
            >
              {loading ? "กำลังดำเนินการ..." : "ยืนยันการสั่งซื้อ"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
