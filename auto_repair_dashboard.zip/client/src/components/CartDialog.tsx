import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useCart } from "@/contexts/CartContext";
import { Minus, Plus, ShoppingCart, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { useState } from "react";
import CheckoutDialog from "./CheckoutDialog";

interface CartDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function CartDialog({ open, onOpenChange }: CartDialogProps) {
  const { cart, updateQuantity, removeFromCart, getTotalPrice, getTotalItems } = useCart();
  const [checkoutOpen, setCheckoutOpen] = useState(false);

  const handleIncreaseQuantity = (productId: number, currentQuantity: number, stock: number) => {
    if (currentQuantity >= stock) {
      toast.error("ไม่สามารถเพิ่มสินค้าเกินจำนวนในสต็อกได้");
      return;
    }
    updateQuantity(productId, currentQuantity + 1);
  };

  const handleDecreaseQuantity = (productId: number, currentQuantity: number) => {
    if (currentQuantity <= 1) {
      removeFromCart(productId);
      toast.success("ลบสินค้าออกจากตะกร้าแล้ว");
      return;
    }
    updateQuantity(productId, currentQuantity - 1);
  };

  const handleRemoveItem = (productId: number) => {
    removeFromCart(productId);
    toast.success("ลบสินค้าออกจากตะกร้าแล้ว");
  };

  const handleCheckout = () => {
    if (cart.length === 0) {
      toast.error("ตะกร้าสินค้าว่างเปล่า");
      return;
    }
    setCheckoutOpen(true);
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-[600px] glass border-primary/30 max-h-[80vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-2xl font-display neon-text">
              <ShoppingCart className="w-6 h-6" />
              ตะกร้าสินค้า
            </DialogTitle>
            <DialogDescription>
              รายการสินค้าที่คุณเลือก ({getTotalItems()} รายการ)
            </DialogDescription>
          </DialogHeader>

          <div className="flex-1 overflow-y-auto space-y-4 py-4">
            {cart.length === 0 ? (
              <div className="text-center py-12">
                <ShoppingCart className="w-16 h-16 text-muted-foreground mx-auto mb-4 opacity-50" />
                <p className="text-muted-foreground">ตะกร้าสินค้าว่างเปล่า</p>
                <p className="text-sm text-muted-foreground mt-2">เพิ่มสินค้าจากหน้าคลังสินค้า</p>
              </div>
            ) : (
              cart.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center gap-4 p-4 rounded-lg bg-card/30 border border-white/10 hover:border-primary/30 transition-colors"
                >
                  <div className="w-16 h-16 rounded-lg bg-white/5 flex items-center justify-center border border-white/10 flex-shrink-0">
                    <ShoppingCart className="w-8 h-8 text-muted-foreground" />
                  </div>

                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-foreground truncate">{item.productName}</h4>
                    <p className="text-sm text-primary font-mono">฿{item.price.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">คงเหลือ: {item.stock}</p>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8 border-white/10 hover:bg-white/5"
                      onClick={() => handleDecreaseQuantity(item.productId, item.quantity)}
                    >
                      <Minus className="h-4 w-4" />
                    </Button>
                    <span className="w-12 text-center font-mono font-semibold">{item.quantity}</span>
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8 border-white/10 hover:bg-white/5"
                      onClick={() => handleIncreaseQuantity(item.productId, item.quantity, item.stock)}
                      disabled={item.quantity >= item.stock}
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="text-right min-w-[80px]">
                    <p className="font-bold text-primary font-mono">
                      ฿{(item.price * item.quantity).toLocaleString()}
                    </p>
                  </div>

                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10"
                    onClick={() => handleRemoveItem(item.productId)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))
            )}
          </div>

          <DialogFooter className="flex-col gap-4 border-t border-white/10 pt-4">
            <div className="flex justify-between items-center w-full text-lg font-semibold">
              <span className="text-muted-foreground">ยอดรวมทั้งหมด:</span>
              <span className="text-2xl text-primary font-display font-bold">
                ฿{getTotalPrice().toLocaleString()}
              </span>
            </div>
            <div className="flex gap-2 w-full">
              <Button
                variant="outline"
                className="flex-1 border-white/10 hover:bg-white/5"
                onClick={() => onOpenChange(false)}
              >
                ปิด
              </Button>
              <Button
                className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_15px_var(--color-primary)]"
                onClick={handleCheckout}
                disabled={cart.length === 0}
              >
                ชำระเงิน
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <CheckoutDialog 
        open={checkoutOpen} 
        onOpenChange={setCheckoutOpen}
        onSuccess={() => {
          setCheckoutOpen(false);
          onOpenChange(false);
        }}
      />
    </>
  );
}
