import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  Wrench, 
  ShoppingCart, 
  Users, 
  Settings, 
  LogOut, 
  Menu,
  Calendar,
  Bell,
  Search
} from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet";

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { user, logout } = useAuth();

  const handleLogout = async () => {
    try {
      await logout();
      toast.success("ออกจากระบบสำเร็จ");
    } catch (error) {
      toast.error("เกิดข้อผิดพลาดในการออกจากระบบ");
    }
  };

  const navItems = [
    { href: "/", icon: LayoutDashboard, label: "ภาพรวมระบบ" },
    { href: "/repairs", icon: Wrench, label: "งานซ่อม" },
    { href: "/inventory", icon: ShoppingCart, label: "คลังสินค้า" },
    { href: "/customers", icon: Users, label: "ลูกค้า" },
    { href: "/appointments", icon: Calendar, label: "นัดหมาย" },
    { href: "/settings", icon: Settings, label: "ตั้งค่า" },
  ];

  const NavContent = () => (
    <div className="flex flex-col h-full">
      <div className="p-6 flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center shadow-[0_0_15px_var(--color-primary)]">
          <Wrench className="text-primary-foreground w-6 h-6" />
        </div>
        <div>
          <h1 className="font-display font-bold text-xl tracking-wider text-foreground">NEO-FIX</h1>
          <p className="text-xs text-muted-foreground font-mono">SYSTEM V.2.0</p>
        </div>
      </div>

      <div className="px-4 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="ค้นหาระบบ..." 
            className="pl-9 bg-background/50 border-white/10 focus:border-primary/50 focus:ring-primary/20"
          />
        </div>
      </div>

      <nav className="flex-1 px-4 space-y-2">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <div
                className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 cursor-pointer group
                  ${isActive 
                    ? "bg-primary/20 text-primary border border-primary/30 shadow-[0_0_10px_var(--color-primary)_inset]" 
                    : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                  }`}
              >
                <item.icon className={`w-5 h-5 ${isActive ? "animate-pulse" : "group-hover:text-primary transition-colors"}`} />
                <span className="font-medium">{item.label}</span>
                {isActive && (
                  <div className="ml-auto w-1.5 h-1.5 rounded-full bg-primary shadow-[0_0_5px_var(--color-primary)]" />
                )}
              </div>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 mt-auto border-t border-white/10">
        <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/5">
          <Avatar className="border-2 border-primary/50">
            <AvatarImage src="https://github.com/shadcn.png" />
            <AvatarFallback>AD</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate text-foreground">{user?.name || "ผู้ใช้งาน"}</p>
            <p className="text-xs text-muted-foreground truncate">{user?.email || "user@neofix.com"}</p>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            className="text-muted-foreground hover:text-destructive"
            onClick={handleLogout}
            title="ออกจากระบบ"
          >
            <LogOut className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background text-foreground flex overflow-hidden selection:bg-primary/30 selection:text-primary-foreground">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-72 border-r border-white/10 bg-card/30 backdrop-blur-xl fixed inset-y-0 left-0 z-50">
        <NavContent />
      </aside>

      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 h-16 border-b border-white/10 bg-background/80 backdrop-blur-md z-40 flex items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center shadow-[0_0_10px_var(--color-primary)]">
            <Wrench className="text-primary-foreground w-5 h-5" />
          </div>
          <span className="font-display font-bold text-lg tracking-wider">NEO-FIX</span>
        </div>
        
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="relative">
            <Bell className="w-5 h-5" />
            <span className="absolute top-2 right-2 w-2 h-2 bg-destructive rounded-full animate-ping" />
            <span className="absolute top-2 right-2 w-2 h-2 bg-destructive rounded-full" />
          </Button>
          
          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="w-6 h-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0 w-80 border-r border-white/10 bg-background/95 backdrop-blur-xl">
              <SheetTitle className="sr-only">เมนูนำทาง</SheetTitle>
              <NavContent />
            </SheetContent>
          </Sheet>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 lg:ml-72 pt-16 lg:pt-0 min-h-screen overflow-y-auto overflow-x-hidden">
        <div className="container py-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
          {children}
        </div>
      </main>
    </div>
  );
}
