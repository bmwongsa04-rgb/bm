import { jsPDF } from "jspdf";

// Load Thai font (Sarabun) - You'll need to add this font to your project
// For now, we'll use default font with English fallback

interface ReceiptData {
  receiptNumber: string;
  date: string;
  customerName: string;
  customerPhone: string;
  customerAddress?: string;
  items: Array<{
    name: string;
    quantity: number;
    price: number;
    total: number;
  }>;
  subtotal: number;
  vat: number;
  total: number;
  paymentMethod?: string;
}

interface TaxInvoiceData extends ReceiptData {
  taxId: string;
  companyName: string;
  companyAddress: string;
  companyPhone: string;
  customerTaxId?: string;
}

interface AppointmentData {
  appointmentNumber: string;
  date: string;
  time: string;
  customerName: string;
  customerPhone: string;
  serviceType: string;
  vehicleInfo?: string;
  notes?: string;
}

export function generateReceipt(data: ReceiptData) {
  const doc = new jsPDF();
  
  // Header
  doc.setFontSize(20);
  doc.text("AUTO REPAIR SHOP", 105, 20, { align: "center" });
  doc.setFontSize(16);
  doc.text("Receipt / Reciept", 105, 30, { align: "center" });
  
  // Receipt Info
  doc.setFontSize(10);
  doc.text(`Receipt No: ${data.receiptNumber}`, 20, 45);
  doc.text(`Date: ${data.date}`, 20, 52);
  
  // Customer Info
  doc.text(`Customer: ${data.customerName}`, 20, 62);
  doc.text(`Phone: ${data.customerPhone}`, 20, 69);
  if (data.customerAddress) {
    doc.text(`Address: ${data.customerAddress}`, 20, 76);
  }
  
  // Table Header
  let y = 90;
  doc.setFillColor(200, 200, 200);
  doc.rect(20, y, 170, 8, "F");
  doc.text("Item", 25, y + 5);
  doc.text("Qty", 120, y + 5);
  doc.text("Price", 140, y + 5);
  doc.text("Total", 165, y + 5, { align: "right" });
  
  // Items
  y += 12;
  data.items.forEach((item) => {
    doc.text(item.name, 25, y);
    doc.text(item.quantity.toString(), 120, y);
    doc.text(item.price.toFixed(2), 140, y);
    doc.text(item.total.toFixed(2), 185, y, { align: "right" });
    y += 7;
  });
  
  // Totals
  y += 5;
  doc.line(20, y, 190, y);
  y += 7;
  doc.text("Subtotal:", 140, y);
  doc.text(data.subtotal.toFixed(2), 185, y, { align: "right" });
  y += 7;
  doc.text(`VAT (7%):`, 140, y);
  doc.text(data.vat.toFixed(2), 185, y, { align: "right" });
  y += 7;
  doc.setFontSize(12);
  doc.text("Total:", 140, y);
  doc.text(data.total.toFixed(2), 185, y, { align: "right" });
  
  if (data.paymentMethod) {
    y += 10;
    doc.setFontSize(10);
    doc.text(`Payment Method: ${data.paymentMethod}`, 20, y);
  }
  
  // Footer
  doc.setFontSize(8);
  doc.text("Thank you for your business!", 105, 280, { align: "center" });
  
  return doc;
}

export function generateTaxInvoice(data: TaxInvoiceData) {
  const doc = new jsPDF();
  
  // Header
  doc.setFontSize(20);
  doc.text(data.companyName, 105, 20, { align: "center" });
  doc.setFontSize(12);
  doc.text(data.companyAddress, 105, 28, { align: "center" });
  doc.text(`Tel: ${data.companyPhone}`, 105, 35, { align: "center" });
  doc.text(`Tax ID: ${data.taxId}`, 105, 42, { align: "center" });
  
  doc.setFontSize(16);
  doc.text("TAX INVOICE", 105, 55, { align: "center" });
  
  // Invoice Info
  doc.setFontSize(10);
  doc.text(`Invoice No: ${data.receiptNumber}`, 20, 70);
  doc.text(`Date: ${data.date}`, 20, 77);
  
  // Customer Info
  doc.text("Bill To:", 20, 90);
  doc.text(data.customerName, 20, 97);
  doc.text(data.customerPhone, 20, 104);
  if (data.customerAddress) {
    doc.text(data.customerAddress, 20, 111);
  }
  if (data.customerTaxId) {
    doc.text(`Tax ID: ${data.customerTaxId}`, 20, 118);
  }
  
  // Table Header
  let y = 130;
  doc.setFillColor(200, 200, 200);
  doc.rect(20, y, 170, 8, "F");
  doc.text("Description", 25, y + 5);
  doc.text("Qty", 120, y + 5);
  doc.text("Price", 140, y + 5);
  doc.text("Amount", 165, y + 5, { align: "right" });
  
  // Items
  y += 12;
  data.items.forEach((item) => {
    doc.text(item.name, 25, y);
    doc.text(item.quantity.toString(), 120, y);
    doc.text(item.price.toFixed(2), 140, y);
    doc.text(item.total.toFixed(2), 185, y, { align: "right" });
    y += 7;
  });
  
  // Totals
  y += 5;
  doc.line(20, y, 190, y);
  y += 7;
  doc.text("Subtotal:", 140, y);
  doc.text(data.subtotal.toFixed(2), 185, y, { align: "right" });
  y += 7;
  doc.text("VAT (7%):", 140, y);
  doc.text(data.vat.toFixed(2), 185, y, { align: "right" });
  y += 7;
  doc.setFontSize(12);
  doc.setFont(undefined, "bold");
  doc.text("Grand Total:", 140, y);
  doc.text(data.total.toFixed(2), 185, y, { align: "right" });
  
  // Footer
  doc.setFontSize(8);
  doc.setFont(undefined, "normal");
  doc.text("This is a computer-generated tax invoice.", 105, 270, { align: "center" });
  doc.text("Thank you for your business!", 105, 277, { align: "center" });
  
  return doc;
}

export function generateAppointmentSlip(data: AppointmentData) {
  const doc = new jsPDF();
  
  // Header
  doc.setFontSize(20);
  doc.text("AUTO REPAIR SHOP", 105, 20, { align: "center" });
  doc.setFontSize(16);
  doc.text("Appointment Confirmation", 105, 30, { align: "center" });
  
  // Appointment Info
  doc.setFontSize(12);
  doc.text(`Appointment No: ${data.appointmentNumber}`, 20, 50);
  
  // Date & Time Box
  doc.setFillColor(240, 240, 240);
  doc.rect(20, 60, 170, 25, "F");
  doc.setFontSize(14);
  doc.setFont(undefined, "bold");
  doc.text("Date & Time", 25, 70);
  doc.setFont(undefined, "normal");
  doc.setFontSize(12);
  doc.text(data.date, 25, 78);
  doc.text(data.time, 25, 85);
  
  // Customer Info
  doc.setFontSize(12);
  doc.setFont(undefined, "bold");
  doc.text("Customer Information", 20, 100);
  doc.setFont(undefined, "normal");
  doc.text(`Name: ${data.customerName}`, 20, 110);
  doc.text(`Phone: ${data.customerPhone}`, 20, 117);
  
  if (data.vehicleInfo) {
    doc.text(`Vehicle: ${data.vehicleInfo}`, 20, 124);
  }
  
  // Service Info
  doc.setFont(undefined, "bold");
  doc.text("Service Type", 20, 140);
  doc.setFont(undefined, "normal");
  doc.text(data.serviceType, 20, 150);
  
  if (data.notes) {
    doc.setFont(undefined, "bold");
    doc.text("Notes", 20, 165);
    doc.setFont(undefined, "normal");
    const splitNotes = doc.splitTextToSize(data.notes, 170);
    doc.text(splitNotes, 20, 175);
  }
  
  // Important Notice
  doc.setFillColor(255, 250, 200);
  doc.rect(20, 220, 170, 30, "F");
  doc.setFontSize(10);
  doc.setFont(undefined, "bold");
  doc.text("Important Notice:", 25, 228);
  doc.setFont(undefined, "normal");
  doc.text("- Please arrive 10 minutes before your appointment time", 25, 235);
  doc.text("- Bring this slip with you", 25, 242);
  doc.text("- Call us if you need to reschedule", 25, 249);
  
  // Footer
  doc.setFontSize(8);
  doc.text("Thank you for choosing our service!", 105, 275, { align: "center" });
  
  return doc;
}

export function downloadPDF(doc: jsPDF, filename: string) {
  doc.save(filename);
}

export function printPDF(doc: jsPDF) {
  doc.autoPrint();
  window.open(doc.output('bloburl'), '_blank');
}
