import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch, Redirect } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import { CartProvider } from "./contexts/CartContext";
import Home from "./pages/Home";
import Repairs from "./pages/Repairs";
import InventoryManagement from "./pages/InventoryManagement";
import Customers from "./pages/Customers";
import Appointments from "./pages/Appointments";
import Settings from "./pages/Settings";
import Login from "./pages/Login";
import Shop from "./pages/Shop";

function RootRedirect() {
  const { isAuthenticated, user, loading } = useAuth();

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  if (!isAuthenticated) return <Redirect to="/login" />;
  if (user?.role === 'member') return <Redirect to="/shop" />;
  return <Redirect to="/dashboard" />;
}

function ProtectedRoute({ component: Component, allowedRoles }: { component: React.ComponentType, allowedRoles?: string[] }) {
  const { user, isAuthenticated, loading } = useAuth();

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  if (!isAuthenticated) {
    return <Redirect to="/login" />;
  }

  if (allowedRoles && user && !allowedRoles.includes(user.role)) {
    return <Redirect to="/shop" />;
  }

  return <Component />;
}
function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/shop" component={Shop} />
      
      {/* Protected Routes for Admin and Employee */}
      <Route path="/dashboard">
        <ProtectedRoute component={Home} allowedRoles={['admin', 'employee']} />
      </Route>
      <Route path="/repairs">
        <ProtectedRoute component={Repairs} allowedRoles={['admin', 'employee']} />
      </Route>
      <Route path="/inventory">
        <ProtectedRoute component={InventoryManagement} allowedRoles={['admin', 'employee']} />
      </Route>
      <Route path="/customers">
        <ProtectedRoute component={Customers} allowedRoles={['admin', 'employee']} />
      </Route>
      <Route path="/appointments">
        <ProtectedRoute component={Appointments} allowedRoles={['admin', 'employee']} />
      </Route>
      <Route path="/settings">
        <ProtectedRoute component={Settings} allowedRoles={['admin', 'employee']} />
      </Route>

      {/* Redirect root to login or dashboard based on auth */}
      <Route path="/" component={RootRedirect} />

      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <AuthProvider>
          <CartProvider>
            <TooltipProvider>
              <Toaster />
              <Router />
            </TooltipProvider>
          </CartProvider>
        </AuthProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
