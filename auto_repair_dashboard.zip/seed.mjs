import { drizzle } from 'drizzle-orm/mysql2';
import mysql from 'mysql2/promise';
import * as schema from './drizzle/schema.js';

const connection = await mysql.createConnection(process.env.DATABASE_URL);
const db = drizzle(connection, { schema, mode: 'default' });

console.log('🌱 Starting database seed...');

// ล้างข้อมูลเดิม (ยกเว้น users)
await db.delete(schema.orderItems);
await db.delete(schema.orders);
await db.delete(schema.repairItems);
await db.delete(schema.repairs);
await db.delete(schema.appointments);
await db.delete(schema.vehicles);
await db.delete(schema.customers);
await db.delete(schema.inventory);

console.log('✅ Cleared existing data');

// เพิ่มข้อมูลลูกค้า
const customers = await db.insert(schema.customers).values([
  {
    name: 'สมชาย ใจดี',
    phone: '081-234-5678',
    email: 'somchai@email.com',
    address: '123 ถนนสุขุมวิท แขวงคลองเตย เขตคลองเตย กรุงเทพฯ 10110',
  },
  {
    name: 'สมหญิง รักษ์ดี',
    phone: '082-345-6789',
    email: 'somying@email.com',
    address: '456 ถนนพระราม 4 แขวงพระโขนง เขตคลองเตย กรุงเทพฯ 10110',
  },
  {
    name: 'วิชัย มั่นคง',
    phone: '083-456-7890',
    email: 'wichai@email.com',
    address: '789 ถนนเพชรบุรี แขวงมักกะสัน เขตราชเทวี กรุงเทพฯ 10400',
  },
  {
    name: 'นิดา สวยงาม',
    phone: '084-567-8901',
    email: 'nida@email.com',
    address: '321 ถนนรัชดาภิเษก แขวงห้วยขวาง เขตห้วยขวาง กรุงเทพฯ 10310',
  },
  {
    name: 'ประยุทธ์ แข็งแรง',
    phone: '085-678-9012',
    email: 'prayuth@email.com',
    address: '654 ถนนพหลโยธิน แขวงจตุจักร เขตจตุจักร กรุงเทพฯ 10900',
  },
]);

console.log('✅ Added 5 customers');

// เพิ่มข้อมูลยานพาหนะ
const vehicles = await db.insert(schema.vehicles).values([
  {
    customerId: 1,
    licensePlate: 'กข-1234',
    brand: 'Toyota',
    model: 'Camry',
    year: 2020,
    color: 'ขาว',
    vin: '1HGBH41JXMN109186',
  },
  {
    customerId: 1,
    licensePlate: 'คง-5678',
    brand: 'Honda',
    model: 'Civic',
    year: 2019,
    color: 'ดำ',
    vin: '2HGFC2F59KH542372',
  },
  {
    customerId: 2,
    licensePlate: 'จฉ-9012',
    brand: 'Mazda',
    model: 'CX-5',
    year: 2021,
    color: 'แดง',
    vin: 'JM3KFBCM5K0639401',
  },
  {
    customerId: 3,
    licensePlate: 'ชซ-3456',
    brand: 'Nissan',
    model: 'Almera',
    year: 2022,
    color: 'เทา',
    vin: '3N1AB8CV8NY123456',
  },
  {
    customerId: 4,
    licensePlate: 'ฌญ-7890',
    brand: 'Isuzu',
    model: 'D-Max',
    year: 2020,
    color: 'น้ำเงิน',
    vin: 'MPATFS85KJK123456',
  },
]);

console.log('✅ Added 5 vehicles');

// เพิ่มข้อมูลสินค้าคงคลัง
const inventory = await db.insert(schema.inventory).values([
  {
    sku: 'OIL-001',
    name: 'น้ำมันเครื่องสังเคราะห์ 5W-30',
    description: 'น้ำมันเครื่องสังเคราะห์แท้ 100% เหมาะสำหรับเครื่องยนต์สมัยใหม่',
    category: 'ของเหลว',
    quantity: 50,
    minQuantity: 10,
    unitPrice: 800,
    sellingPrice: 1200,
    supplier: 'บริษัท น้ำมันไทย จำกัด',
    location: 'ชั้น A-01',
  },
  {
    sku: 'FIL-001',
    name: 'ไส้กรองน้ำมันเครื่อง (Toyota)',
    description: 'ไส้กรองน้ำมันเครื่องสำหรับรถยนต์ Toyota ทุกรุ่น',
    category: 'ไส้กรอง',
    quantity: 100,
    minQuantity: 20,
    unitPrice: 150,
    sellingPrice: 250,
    supplier: 'บริษัท อะไหล่รถยนต์ จำกัด',
    location: 'ชั้น B-05',
  },
  {
    sku: 'BRK-001',
    name: 'ผ้าเบรกหน้า',
    description: 'ผ้าเบรกคุณภาพสูง ทนทาน ไม่เสียงดัง',
    category: 'เบรก',
    quantity: 30,
    minQuantity: 5,
    unitPrice: 1200,
    sellingPrice: 1800,
    supplier: 'บริษัท เบรกดี จำกัด',
    location: 'ชั้น C-03',
  },
  {
    sku: 'SPK-001',
    name: 'หัวเทียน (Iridium)',
    description: 'หัวเทียนอิริเดียม อายุการใช้งานยาวนาน',
    category: 'ระบบจุดระเบิด',
    quantity: 80,
    minQuantity: 15,
    unitPrice: 200,
    sellingPrice: 350,
    supplier: 'บริษัท หัวเทียนไทย จำกัด',
    location: 'ชั้น D-02',
  },
  {
    sku: 'BAT-001',
    name: 'แบตเตอรี่ 12V 45Ah',
    description: 'แบตเตอรี่รถยนต์คุณภาพสูง รับประกัน 2 ปี',
    category: 'ระบบไฟฟ้า',
    quantity: 20,
    minQuantity: 5,
    unitPrice: 1500,
    sellingPrice: 2200,
    supplier: 'บริษัท แบตเตอรี่ไทย จำกัด',
    location: 'ชั้น E-01',
  },
  {
    sku: 'WIP-001',
    name: 'ใบปัดน้ำฝน 24 นิ้ว',
    description: 'ใบปัดน้ำฝนคุณภาพดี ปัดสะอาด ไม่มีรอยขีด',
    category: 'ภายนอก',
    quantity: 60,
    minQuantity: 10,
    unitPrice: 180,
    sellingPrice: 300,
    supplier: 'บริษัท ใบปัดไทย จำกัด',
    location: 'ชั้น F-04',
  },
  {
    sku: 'COL-001',
    name: 'น้ำยาหล่อเย็น (ผสมเสร็จ)',
    description: 'น้ำยาหล่อเย็นพร้อมใช้ ไม่ต้องผสมน้ำ',
    category: 'ของเหลว',
    quantity: 40,
    minQuantity: 10,
    unitPrice: 120,
    sellingPrice: 180,
    supplier: 'บริษัท น้ำยาไทย จำกัด',
    location: 'ชั้น A-03',
  },
  {
    sku: 'TIR-001',
    name: 'ยางรถยนต์ 195/60 R15',
    description: 'ยางรถยนต์คุณภาพดี ยึดเกาะถนนดี',
    category: 'ยาง',
    quantity: 16,
    minQuantity: 4,
    unitPrice: 1800,
    sellingPrice: 2500,
    supplier: 'บริษัท ยางไทย จำกัด',
    location: 'คลังยาง',
  },
]);

console.log('✅ Added 8 inventory items');

// เพิ่มข้อมูลงานซ่อม
const repairs = await db.insert(schema.repairs).values([
  {
    repairCode: 'REP-2025-001',
    vehicleId: 1,
    customerId: 1,
    assignedTo: 1,
    description: 'เปลี่ยนถ่ายน้ำมันเครื่อง + ไส้กรอง',
    status: 'completed',
    startDate: new Date('2025-01-05'),
    completedDate: new Date('2025-01-05'),
    estimatedCost: 1500,
    actualCost: 1450,
    notes: 'งานเสร็จตามกำหนด ลูกค้าพอใจ',
  },
  {
    repairCode: 'REP-2025-002',
    vehicleId: 3,
    customerId: 2,
    assignedTo: 1,
    description: 'เปลี่ยนผ้าเบรกหน้า + ตรวจเช็คระบบเบรก',
    status: 'in_progress',
    startDate: new Date('2025-01-10'),
    estimatedCost: 2500,
    notes: 'รอลูกค้ายืนยันเปลี่ยนดิสก์เบรก',
  },
  {
    repairCode: 'REP-2025-003',
    vehicleId: 4,
    customerId: 3,
    assignedTo: 1,
    description: 'เปลี่ยนแบตเตอรี่ + ตรวจสอบระบบไฟฟ้า',
    status: 'pending',
    estimatedCost: 2500,
    notes: 'รออะไหล่เข้า',
  },
]);

console.log('✅ Added 3 repairs');

// เพิ่มข้อมูลนัดหมาย
const appointments = await db.insert(schema.appointments).values([
  {
    customerId: 5,
    vehicleId: 5,
    appointmentDate: new Date('2025-01-15 10:00:00'),
    serviceType: 'ตรวจเช็คระยะ 10,000 กม.',
    description: 'ตรวจเช็คเครื่องยนต์ ระบบเบรก ระบบกันสะเทือน',
    status: 'confirmed',
    notes: 'ลูกค้าต้องการรับรถภายใน 2 ชั่วโมง',
  },
  {
    customerId: 1,
    vehicleId: 2,
    appointmentDate: new Date('2025-01-16 14:00:00'),
    serviceType: 'เปลี่ยนยาง 4 เส้น',
    description: 'เปลี่ยนยางรถยนต์ทั้ง 4 เส้น + ถ่วงล้อ',
    status: 'scheduled',
  },
]);

console.log('✅ Added 2 appointments');

// เพิ่มข้อมูลคำสั่งซื้อ
const orders = await db.insert(schema.orders).values([
  {
    orderCode: 'ORD-2025-001',
    customerId: 1,
    customerName: 'สมชาย ใจดี',
    customerPhone: '081-234-5678',
    customerEmail: 'somchai@email.com',
    shippingAddress: '123 ถนนสุขุมวิท แขวงคลองเตย เขตคลองเตย กรุงเทพฯ 10110',
    totalAmount: 3600,
    status: 'delivered',
    paymentMethod: 'เงินสด',
    paymentStatus: 'paid',
  },
  {
    orderCode: 'ORD-2025-002',
    customerName: 'วิไล สุขใจ',
    customerPhone: '086-789-0123',
    customerEmail: 'wilai@email.com',
    shippingAddress: '999 ถนนลาดพร้าว แขวงจอมพล เขตจตุจักร กรุงเทพฯ 10900',
    totalAmount: 1500,
    status: 'confirmed',
    paymentMethod: 'โอนเงิน',
    paymentStatus: 'paid',
  },
]);

console.log('✅ Added 2 orders');

await connection.end();

console.log('🎉 Database seed completed successfully!');
