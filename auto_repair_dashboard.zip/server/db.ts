import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, User, repairs, InsertRepair, Repair, customers, vehicles, inventory, InsertInventory, Inventory, InsertCustomer, Customer, Vehicle, InsertVehicle, appointments, InsertAppointment, Appointment } from "../drizzle/schema";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function getUserByUsername(username: string): Promise<User | undefined> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  try {
    const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0];
  } catch (error) {
    console.error("[Database] Error getting user by username:", error);
    return undefined;
  }
}

export async function getUserById(id: number): Promise<User | undefined> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  try {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  } catch (error) {
    console.error("[Database] Error getting user by id:", error);
    return undefined;
  }
}

export async function createUser(user: InsertUser): Promise<User | undefined> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create user: database not available");
    return undefined;
  }

  try {
    const result = await db.insert(users).values(user);
    if (result && result[0] && result[0].insertId) {
      return getUserById(Number(result[0].insertId));
    }
    return undefined;
  } catch (error) {
    console.error("[Database] Error creating user:", error);
    return undefined;
  }
}

export async function updateUser(id: number, updates: Partial<InsertUser>): Promise<User | undefined> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update user: database not available");
    return undefined;
  }

  try {
    await db.update(users).set(updates).where(eq(users.id, id));
    return getUserById(id);
  } catch (error) {
    console.error("[Database] Error updating user:", error);
    return undefined;
  }
}

export async function deleteUser(id: number): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot delete user: database not available");
    return false;
  }

  try {
    await db.delete(users).where(eq(users.id, id));
    return true;
  } catch (error) {
    console.error("[Database] Error deleting user:", error);
    return false;
  }
}

export async function getAllUsers(): Promise<User[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get users: database not available");
    return [];
  }

  try {
    return await db.select().from(users);
  } catch (error) {
    console.error("[Database] Error getting all users:", error);
    return [];
  }
}

// ==================== REPAIRS ====================

export async function getAllRepairs(): Promise<Repair[]> {
  const db = await getDb();
  if (!db) return [];
  
  try {
    return await db.select().from(repairs);
  } catch (error) {
    console.error("[Database] Error getting all repairs:", error);
    return [];
  }
}

export async function getRepairById(id: number): Promise<Repair | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  try {
    const result = await db.select().from(repairs).where(eq(repairs.id, id)).limit(1);
    return result[0];
  } catch (error) {
    console.error("[Database] Error getting repair by id:", error);
    return undefined;
  }
}

export async function createRepair(data: InsertRepair): Promise<Repair> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  try {
    const result = await db.insert(repairs).values(data) as any;
    const newRepair = await getRepairById(Number(result.insertId));
    if (!newRepair) throw new Error("Failed to create repair");
    return newRepair;
  } catch (error) {
    console.error("[Database] Error creating repair:", error);
    throw error;
  }
}

export async function updateRepair(id: number, data: Partial<InsertRepair>): Promise<Repair> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  try {
    await db.update(repairs).set(data).where(eq(repairs.id, id));
    const updated = await getRepairById(id);
    if (!updated) throw new Error("Failed to update repair");
    return updated;
  } catch (error) {
    console.error("[Database] Error updating repair:", error);
    throw error;
  }
}

export async function deleteRepair(id: number): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  try {
    await db.delete(repairs).where(eq(repairs.id, id));
    return true;
  } catch (error) {
    console.error("[Database] Error deleting repair:", error);
    throw error;
  }
}

// ==================== INVENTORY ====================
export async function getAllInventory(): Promise<Inventory[]> {
  const db = await getDb();
  if (!db) return [];
  
  try {
    return await db.select().from(inventory);
  } catch (error) {
    console.error("[Database] Error getting all inventory:", error);
    return [];
  }
}

export async function getInventoryById(id: number): Promise<Inventory | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  try {
    const result = await db.select().from(inventory).where(eq(inventory.id, id)).limit(1);
    return result[0];
  } catch (error) {
    console.error("[Database] Error getting inventory by id:", error);
    return undefined;
  }
}

export async function createInventory(data: InsertInventory): Promise<Inventory> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  try {
    const result = await db.insert(inventory).values(data) as any;
    const newItem = await getInventoryById(Number(result.insertId));
    if (!newItem) throw new Error("Failed to create inventory item");
    return newItem;
  } catch (error) {
    console.error("[Database] Error creating inventory:", error);
    throw error;
  }
}

export async function updateInventory(id: number, data: Partial<InsertInventory>): Promise<Inventory> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  try {
    await db.update(inventory).set(data).where(eq(inventory.id, id));
    const updated = await getInventoryById(id);
    if (!updated) throw new Error("Failed to update inventory");
    return updated;
  } catch (error) {
    console.error("[Database] Error updating inventory:", error);
    throw error;
  }
}

export async function deleteInventory(id: number): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  try {
    await db.delete(inventory).where(eq(inventory.id, id));
    return true;
  } catch (error) {
    console.error("[Database] Error deleting inventory:", error);
    throw error;
  }
}

// ==================== CUSTOMERS ====================
export async function getAllCustomers(): Promise<Customer[]> {
  const db = await getDb();
  if (!db) return [];
  
  try {
    return await db.select().from(customers);
  } catch (error) {
    console.error("[Database] Error getting all customers:", error);
    return [];
  }
}

export async function getCustomerById(id: number): Promise<Customer | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  try {
    const result = await db.select().from(customers).where(eq(customers.id, id)).limit(1);
    return result[0];
  } catch (error) {
    console.error("[Database] Error getting customer by id:", error);
    return undefined;
  }
}

export async function createCustomer(data: InsertCustomer): Promise<Customer> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  try {
    const result = await db.insert(customers).values(data) as any;
    const newCustomer = await getCustomerById(Number(result.insertId));
    if (!newCustomer) throw new Error("Failed to create customer");
    return newCustomer;
  } catch (error) {
    console.error("[Database] Error creating customer:", error);
    throw error;
  }
}

export async function updateCustomer(id: number, data: Partial<InsertCustomer>): Promise<Customer> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  try {
    await db.update(customers).set(data).where(eq(customers.id, id));
    const updated = await getCustomerById(id);
    if (!updated) throw new Error("Failed to update customer");
    return updated;
  } catch (error) {
    console.error("[Database] Error updating customer:", error);
    throw error;
  }
}

export async function deleteCustomer(id: number): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  try {
    await db.delete(customers).where(eq(customers.id, id));
    return true;
  } catch (error) {
    console.error("[Database] Error deleting customer:", error);
    throw error;
  }
}

// ==================== VEHICLES ====================
export async function getAllVehicles(): Promise<Vehicle[]> {
  const db = await getDb();
  if (!db) return [];
  
  try {
    return await db.select().from(vehicles);
  } catch (error) {
    console.error("[Database] Error getting all vehicles:", error);
    return [];
  }
}

export async function getVehicleById(id: number): Promise<Vehicle | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  try {
    const result = await db.select().from(vehicles).where(eq(vehicles.id, id)).limit(1);
    return result[0];
  } catch (error) {
    console.error("[Database] Error getting vehicle by id:", error);
    return undefined;
  }
}

export async function createVehicle(data: InsertVehicle): Promise<Vehicle> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  try {
    const result = await db.insert(vehicles).values(data) as any;
    const newVehicle = await getVehicleById(Number(result.insertId));
    if (!newVehicle) throw new Error("Failed to create vehicle");
    return newVehicle;
  } catch (error) {
    console.error("[Database] Error creating vehicle:", error);
    throw error;
  }
}

export async function updateVehicle(id: number, data: Partial<InsertVehicle>): Promise<Vehicle> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  try {
    await db.update(vehicles).set(data).where(eq(vehicles.id, id));
    const updated = await getVehicleById(id);
    if (!updated) throw new Error("Failed to update vehicle");
    return updated;
  } catch (error) {
    console.error("[Database] Error updating vehicle:", error);
    throw error;
  }
}

export async function deleteVehicle(id: number): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  try {
    await db.delete(vehicles).where(eq(vehicles.id, id));
    return true;
  } catch (error) {
    console.error("[Database] Error deleting vehicle:", error);
    throw error;
  }
}

// ==================== APPOINTMENTS ====================
export async function getAllAppointments(): Promise<Appointment[]> {
  const db = await getDb();
  if (!db) return [];
  
  try {
    return await db.select().from(appointments);
  } catch (error) {
    console.error("[Database] Error getting all appointments:", error);
    return [];
  }
}

export async function getAppointmentById(id: number): Promise<Appointment | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  try {
    const result = await db.select().from(appointments).where(eq(appointments.id, id)).limit(1);
    return result[0];
  } catch (error) {
    console.error("[Database] Error getting appointment by id:", error);
    return undefined;
  }
}

export async function createAppointment(data: InsertAppointment): Promise<Appointment> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  try {
    const result = await db.insert(appointments).values(data) as any;
    const newAppointment = await getAppointmentById(Number(result.insertId));
    if (!newAppointment) throw new Error("Failed to create appointment");
    return newAppointment;
  } catch (error) {
    console.error("[Database] Error creating appointment:", error);
    throw error;
  }
}

export async function updateAppointment(id: number, data: Partial<InsertAppointment>): Promise<Appointment> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  try {
    await db.update(appointments).set(data).where(eq(appointments.id, id));
    const updated = await getAppointmentById(id);
    if (!updated) throw new Error("Failed to update appointment");
    return updated;
  } catch (error) {
    console.error("[Database] Error updating appointment:", error);
    throw error;
  }
}

export async function deleteAppointment(id: number): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  try {
    await db.delete(appointments).where(eq(appointments.id, id));
    return true;
  } catch (error) {
    console.error("[Database] Error deleting appointment:", error);
    throw error;
  }
}


// ==================== CUSTOMER RELATIONS ====================
export async function getVehiclesByCustomerId(customerId: number): Promise<Vehicle[]> {
  const db = await getDb();
  if (!db) return [];
  
  try {
    return await db.select().from(vehicles).where(eq(vehicles.customerId, customerId));
  } catch (error) {
    console.error("[Database] Error getting vehicles by customer id:", error);
    return [];
  }
}

export async function getRepairsByCustomerId(customerId: number): Promise<Repair[]> {
  const db = await getDb();
  if (!db) return [];
  
  try {
    return await db.select().from(repairs).where(eq(repairs.customerId, customerId));
  } catch (error) {
    console.error("[Database] Error getting repairs by customer id:", error);
    return [];
  }
}
