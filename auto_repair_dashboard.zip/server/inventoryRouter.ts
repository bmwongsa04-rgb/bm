import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import * as db from "./db";

export const inventoryRouter = router({
  getAll: publicProcedure.query(async () => {
    return await db.getAllInventory();
  }),

  getById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return await db.getInventoryById(input.id);
    }),

  create: publicProcedure
    .input(
      z.object({
        sku: z.string(),
        name: z.string(),
        description: z.string().optional(),
        category: z.string(),
        quantity: z.number().default(0),
        minQuantity: z.number().default(5),
        unitPrice: z.number(),
        sellingPrice: z.number(),
        supplier: z.string().optional(),
        location: z.string().optional(),
        imageUrl: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      return await db.createInventory(input);
    }),

  update: publicProcedure
    .input(
      z.object({
        id: z.number(),
        sku: z.string().optional(),
        name: z.string().optional(),
        description: z.string().optional(),
        category: z.string().optional(),
        quantity: z.number().optional(),
        minQuantity: z.number().optional(),
        unitPrice: z.number().optional(),
        sellingPrice: z.number().optional(),
        supplier: z.string().optional(),
        location: z.string().optional(),
        imageUrl: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      return await db.updateInventory(id, data);
    }),

  delete: publicProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      return await db.deleteInventory(input.id);
    }),
});
