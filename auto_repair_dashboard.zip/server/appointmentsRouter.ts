import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import * as db from "./db";

export const appointmentsRouter = router({
  getAll: publicProcedure.query(async () => {
    return await db.getAllAppointments();
  }),

  getById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return await db.getAppointmentById(input.id);
    }),

  create: publicProcedure
    .input(
      z.object({
        customerId: z.number(),
        vehicleId: z.number(),
        appointmentDate: z.date(),
        serviceType: z.string(),
        description: z.string().optional(),
        status: z.enum(["scheduled", "confirmed", "completed", "cancelled"]).default("scheduled"),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      return await db.createAppointment(input);
    }),

  update: publicProcedure
    .input(
      z.object({
        id: z.number(),
        appointmentDate: z.date().optional(),
        serviceType: z.string().optional(),
        description: z.string().optional(),
        status: z.enum(["scheduled", "confirmed", "completed", "cancelled"]).optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      return await db.updateAppointment(id, data);
    }),

  delete: publicProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      return await db.deleteAppointment(input.id);
    }),
});
