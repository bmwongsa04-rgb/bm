import { TRPCError } from "@trpc/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import * as db from "./db";

export const authRouter = router({
  // Login with username/password
  login: publicProcedure
    .input(
      z.object({
        username: z.string().min(1),
        password: z.string().min(1),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const user = await db.getUserByUsername(input.username);

      if (!user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง",
        });
      }

      const isValidPassword = await bcrypt.compare(input.password, user.password);

      if (!isValidPassword) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง",
        });
      }

      // Update last signed in
      await db.updateUser(user.id, {
        lastSignedIn: new Date(),
      });

      // Store user info in session (you'll need to implement session storage)
      // For now, we'll return user data
      return {
        id: user.id,
        username: user.username,
        name: user.name,
        email: user.email,
        role: user.role,
        phone: user.phone,
        position: user.position,
      };
    }),

  // Get all users (admin only)
  getAllUsers: publicProcedure.query(async () => {
    const users = await db.getAllUsers();
    return users.map((user) => ({
      id: user.id,
      username: user.username,
      name: user.name,
      email: user.email,
      role: user.role,
      phone: user.phone,
      address: user.address,
      salary: user.salary,
      position: user.position,
      createdAt: user.createdAt,
      lastSignedIn: user.lastSignedIn,
    }));
  }),

  // Create user (admin only)
  createUser: publicProcedure
    .input(
      z.object({
        username: z.string().min(3),
        password: z.string().min(6),
        name: z.string().optional(),
        email: z.string().email().or(z.literal("")).optional(),
        role: z.enum(["admin", "employee", "member", "guest"]),
        phone: z.string().optional(),
        address: z.string().optional(),
        salary: z.number().optional(),
        position: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      // Check if username already exists
      const existingUser = await db.getUserByUsername(input.username);
      if (existingUser) {
        throw new TRPCError({
          code: "CONFLICT",
          message: "ชื่อผู้ใช้นี้ถูกใช้งานแล้ว",
        });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(input.password, 10);

      // Create user
      const user = await db.createUser({
        username: input.username,
        password: hashedPassword,
        name: input.name || null,
        email: input.email || null,
        role: input.role,
        phone: input.phone || null,
        address: input.address || null,
        salary: input.salary,
        position: input.position || null,
      });

      if (!user) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "ไม่สามารถสร้างผู้ใช้ได้",
        });
      }

      return {
        id: user.id,
        username: user.username,
        name: user.name,
        email: user.email,
        role: user.role,
      };
    }),

  // Update user (admin only)
  updateUser: publicProcedure
    .input(
      z.object({
        id: z.number(),
        username: z.string().min(3).optional(),
        password: z.string().min(6).optional(),
        name: z.string().optional(),
        email: z.string().email().or(z.literal("")).optional(),
        role: z.enum(["admin", "employee", "member", "guest"]).optional(),
        phone: z.string().optional(),
        address: z.string().optional(),
        salary: z.number().optional(),
        position: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const updates: any = { ...input };
      delete updates.id;

      // Hash password if provided
      if (updates.password) {
        updates.password = await bcrypt.hash(updates.password, 10);
      }

      const user = await db.updateUser(input.id, updates);

      if (!user) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "ไม่พบผู้ใช้",
        });
      }

      return {
        id: user.id,
        username: user.username,
        name: user.name,
        email: user.email,
        role: user.role,
      };
    }),

  // Delete user (admin only)
  deleteUser: publicProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const success = await db.deleteUser(input.id);

      if (!success) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "ไม่พบผู้ใช้",
        });
      }

      return { success: true };
    }),
});
