import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { authRouter } from "./authRouter";
import { repairsRouter } from "./repairsRouter";
import { inventoryRouter } from "./inventoryRouter";
import { customersRouter } from "./customersRouter";
import { appointmentsRouter } from "./appointmentsRouter";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
    // Custom auth procedures
    ...authRouter._def.procedures,
  }),

  // Feature routers
  repairs: repairsRouter,
  inventory: inventoryRouter,
  customers: customersRouter,
  appointments: appointmentsRouter,
});

export type AppRouter = typeof appRouter;
