import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import * as db from "./db";

export const customersRouter = router({
  getAll: publicProcedure.query(async () => {
    return await db.getAllCustomers();
  }),

  getById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return await db.getCustomerById(input.id);
    }),

  create: publicProcedure
    .input(
      z.object({
        name: z.string(),
        phone: z.string(),
        email: z.string().optional(),
        address: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      return await db.createCustomer(input);
    }),

  update: publicProcedure
    .input(
      z.object({
        id: z.number(),
        name: z.string().optional(),
        phone: z.string().optional(),
        email: z.string().optional(),
        address: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      return await db.updateCustomer(id, data);
    }),

  delete: publicProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      return await db.deleteCustomer(input.id);
    }),

  // Get customer's vehicles
  getVehicles: publicProcedure
    .input(z.object({ customerId: z.number() }))
    .query(async ({ input }) => {
      return await db.getVehiclesByCustomerId(input.customerId);
    }),

  // Get customer's repair history
  getRepairHistory: publicProcedure
    .input(z.object({ customerId: z.number() }))
    .query(async ({ input }) => {
      return await db.getRepairsByCustomerId(input.customerId);
    }),
});
