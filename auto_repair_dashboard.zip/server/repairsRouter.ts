import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import * as db from "./db";

export const repairsRouter = router({
  // ดึงรายการงานซ่อมทั้งหมด
  getAll: publicProcedure.query(async () => {
    return await db.getAllRepairs();
  }),

  // ดึงงานซ่อมตาม ID
  getById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return await db.getRepairById(input.id);
    }),

  // สร้างงานซ่อมใหม่
  create: publicProcedure
    .input(
      z.object({
        repairCode: z.string(),
        vehicleId: z.number(),
        customerId: z.number(),
        assignedTo: z.number().optional(),
        description: z.string(),
        status: z.enum(["pending", "in_progress", "completed", "cancelled"]).default("pending"),
        estimatedCost: z.number().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      return await db.createRepair(input);
    }),

  // อัปเดตงานซ่อม
  update: publicProcedure
    .input(
      z.object({
        id: z.number(),
        assignedTo: z.number().optional(),
        description: z.string().optional(),
        status: z.enum(["pending", "in_progress", "completed", "cancelled"]).optional(),
        startDate: z.date().optional(),
        completedDate: z.date().optional(),
        estimatedCost: z.number().optional(),
        actualCost: z.number().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      return await db.updateRepair(id, data);
    }),

  // ลบงานซ่อม
  delete: publicProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      return await db.deleteRepair(input.id);
    }),
});
