import { describe, it, expect } from 'vitest';
import * as db from './db';
import bcrypt from 'bcryptjs';

describe('Auth System', () => {
  it('should have admin user in database', async () => {
    const admin = await db.getUserByUsername('admin');
    
    expect(admin).toBeDefined();
    expect(admin?.username).toBe('admin');
    expect(admin?.role).toBe('admin');
  });

  it('should verify admin password correctly', async () => {
    const admin = await db.getUserByUsername('admin');
    
    expect(admin).toBeDefined();
    
    if (admin) {
      const isValid = await bcrypt.compare('admin2543', admin.password);
      expect(isValid).toBe(true);
    }
  });

  it('should get all users from database', async () => {
    const users = await db.getAllUsers();
    
    expect(users).toBeDefined();
    expect(Array.isArray(users)).toBe(true);
    expect(users.length).toBeGreaterThanOrEqual(3); // admin + 2 employees
  });

  it('should have employees in database', async () => {
    const somchai = await db.getUserByUsername('somchai');
    const wichai = await db.getUserByUsername('wichai');
    
    expect(somchai).toBeDefined();
    expect(somchai?.role).toBe('employee');
    
    expect(wichai).toBeDefined();
    expect(wichai?.role).toBe('employee');
  });
});
